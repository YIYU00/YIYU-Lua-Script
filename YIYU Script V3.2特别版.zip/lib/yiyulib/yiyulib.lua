
   local values = {
    [0] = 0,
    [1] = 50,
    [2] = 88,
    [3] = 160,
    [4] = 208,
}
local exp_animal = 'a_c_killerwhale'
local explosive_animal_gun
function expaniamlgun(toggle)
    explosive_animal_gun = toggle
    while explosive_animal_gun do
        local weaponHash = WEAPON.GET_SELECTED_PED_WEAPON(players.user_ped())
        local weaponType = WEAPON.GET_WEAPON_DAMAGE_TYPE(weaponHash)
        if weaponType == 3 or (weaponType == 5 and WEAPON.GET_WEAPONTYPE_GROUP(weaponHash) != 1548507267) then --weapons that shoot bullets or explosions and isn't in the throwables category (grenades, proximity mines etc...)
            disable_firing = true
            disableFiringLoop()
            if JSkey.is_disabled_control_pressed(2, 'INPUT_ATTACK') and PLAYER.IS_PLAYER_FREE_AIMING(players.user_ped()) then
                util.create_thread(function()
                    local hash = util.joaat(exp_animal)
                    loadModel(hash)

                    local dir, c1 = direction()
                    local animal = entities.create_ped(28, hash, c1, 0)
                    local cam_rot = CAM.GET_FINAL_RENDERED_CAM_ROT(2)

                    ENTITY.APPLY_FORCE_TO_ENTITY(animal, 0, dir.x, dir.y, dir.z, 0.0, 0.0, 0.0, 0, true, false, true, false, true)
                    ENTITY.SET_ENTITY_ROTATION(animal, cam_rot.x, cam_rot.y, cam_rot.z, 1, true)

                    while not ENTITY.HAS_ENTITY_COLLIDED_WITH_ANYTHING(animal) do
                        util.yield()
                    end
                    local animalPos = ENTITY.GET_ENTITY_COORDS(animal, true)
                    entities.delete_by_handle(animal)
                    FIRE.ADD_EXPLOSION(animalPos.x, animalPos.y,animalPos.z, 1, 10, true, false, 1, false)
                end)
            end
        else
            disable_firing = false
        end
        util.yield(200)
    end
    disable_firing = false
end

function setanimal(text)
    exp_animal = animalsTable[text]
end

local impactCords = v3.new()
local blocks = {}
function xxxminecraftgun()
    if WEAPON.GET_PED_LAST_WEAPON_IMPACT_COORD(players.user_ped(), impactCords) then
        local hash = util.joaat('prop_mb_sandblock_01')
        loadModel(hash)
        blocks[#blocks + 1] = entities.create_object(hash, impactCords)
    end
end
   
   local function player_toggle_loop(root, pid, menu_name, command_names, help_text, callback)
        return menu.toggle_loop(root, menu_name, command_names, help_text, function()
            if not players.exists(pid) then util.stop_thread() end
            callback()
        end)
    end
    
    local spawned_objects = {}
    local ladder_objects = {}
    local function get_transition_state(pid)
        return memory.read_int(memory.script_global(((0x2908D3 + 1) + (pid * 0x1C5)) + 230))
    end
    
    local function get_interior_player_is_in(pid)
        return memory.read_int(memory.script_global(((0x2908D3 + 1) + (pid * 0x1C5)) + 243)) 
    end
    
    local function is_player_in_interior(pid)
        return (memory.read_int(memory.script_global(0x2908D3 + 1 + (pid * 0x1C5) + 243)) ~= 0)
    end
    
    local function get_entity_owner(addr)
        if util.is_session_started() and not util.is_session_transition_active() then
            local netObject = memory.read_long(addr + 0xD0)
            if netObject == 0 then
                return -1
            end
            local owner = memory.read_byte(netObject + 0x49)
            return owner
        end
        return players.user()
    end
    
    local function setBit(addr, bitIndex)
        memory.write_int(addr, memory.read_int(addr) | (1<<bitIndex))
    end
    
    local function clearBit(addr, bitIndex)
        memory.write_int(addr, memory.read_int(addr) & ~(1<<bitIndex))
    end
    
    function GetPlayerCurrentFmActivity(player)
        if player ~= -1 then
            return read_global.int(1892703 + (player * 599 + 1))
        end
        return -1
    end

function draw_string(s, x, y, scale, font)
    HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
    HUD.SET_TEXT_FONT(font or 0)
    HUD.SET_TEXT_SCALE(scale, scale)
    HUD.SET_TEXT_DROP_SHADOW()
    HUD.SET_TEXT_WRAP(0.0, 1.0)
    HUD.SET_TEXT_DROPSHADOW(1, 0, 0, 0, 0)
    HUD.SET_TEXT_OUTLINE()
    HUD.SET_TEXT_EDGE(1, 0, 0, 0, 0)
    HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(s)
    HUD.END_TEXT_COMMAND_DISPLAY_TEXT(x, y)
 end
 



 local replayInterface = memory.read_long(memory.rip(memory.scan("48 8D 0D ? ? ? ? 48 8B D7 E8 ? ? ? ? 48 8D 0D ? ? ? ? 8A D8 E8 ? ? ? ? 84 DB 75 13 48 8D 0D") + 3))
 local pedInterface = memory.read_long(replayInterface + 0x0018)
 local vehInterface = memory.read_long(replayInterface + 0x0010)
 local objectInterface = memory.read_long(replayInterface + 0x0028)
 local pickupInterface = memory.read_long(replayInterface + 0x0020)
function zhujixvlie()
    inviciamountint = 0
               for pid = 0, 31 do
                   if players.exists(pid) and pid ~= players.user() then
                       local pped = players.user_ped(pid)
                       if pped ~= 0 then
                           if players.is_marked_as_modder(pid) then 
                               inviciamountint = inviciamountint + 1
                           end
                       end
                   end
    local ente
                       local ent1e = players.user_ped()
                       local ent2e = PED.GET_VEHICLE_PED_IS_USING(players.user_ped())
                       if PED.IS_PED_IN_ANY_VEHICLE(ent1e,true) then
                           ente = ent2e
                       else
                           ente = ent1e
                       end
                       local speede = ENTITY.GET_ENTITY_SPEED(ente)
                       local speedcalce = speede * 3.6
                       myspeed1e = math.ceil(speedcalce)
               end
                   inviciamountintt = inviciamountint
               draw_string(string.format("~bold~战局人数: ~g~"..#players.list()), 0.165,0.776, 0.4,1) 
               draw_string(string.format("~bold~作弊者: ~r~"..inviciamountintt), 0.165,0.803, 0.4,1) 
               draw_string(string.format("~bold~战局主机: ~y~"..players.get_name(players.get_host())), 0.165,0.830, 0.4,1)
               draw_string(string.format("~bold~脚本主机: ~b~"..players.get_name(players.get_script_host())), 0.165,0.857, 0.4,1)
               draw_string(string.format("~bold~~w~Ped: ~o~"..memory.read_int(pedInterface + 0x0110).."/"..memory.read_int(pedInterface + 0x0108)), 0.165,0.884, 0.4,1)
               draw_string(string.format("~bold~~w~载具: ~p~"..memory.read_int(vehInterface + 0x0190).."/"..memory.read_int(vehInterface + 0x0188)), 0.165,0.911, 0.4,1)
               draw_string(string.format("~bold~~w~物体: ~g~"..memory.read_int(objectInterface + 0x0168).."/"..memory.read_int(objectInterface + 0x0160)), 0.165,0.938, 0.4,1)
               draw_string(string.format("~bold~~w~可拾取物: ~y~"..memory.read_int(pickupInterface + 0x0110).."/"..memory.read_int(pickupInterface + 0x0108)), 0.165,0.965, 0.4,1)
    end

    function CreatePed(index, Hash, Pos, Heading)
        STREAMING.REQUEST_MODEL(Hash)
        while not STREAMING.HAS_MODEL_LOADED(Hash) do util.yield() end
        local SpawnedVehicle = entities.create_ped(index, Hash, Pos, Heading)
        STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(Hash)
        return SpawnedVehicle
    end
    

    





